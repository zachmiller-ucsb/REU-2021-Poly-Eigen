function colors = plotscatter_grad_redgreen(n)
% Return a color gradient from start to stop, in n steps.

    red = [1 0 0];
    green = [0 0.7 0];

    colors = color_gradient(red, green, n);
end
