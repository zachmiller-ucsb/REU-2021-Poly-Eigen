function colors = plotscatter_black(n)
% Return a color gradient from start to stop, in n steps.

    colors = color_gradient([0 0 0], [0 0 0], n);
end
