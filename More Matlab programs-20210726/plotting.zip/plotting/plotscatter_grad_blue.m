function colors = plotscatter_grad_blue(n)
% Return a color gradient from start to stop, in n steps.

    blue = [0 0 1];
    lightblue = [29 67 78] / 78;

    colors = color_gradient(blue, lightblue, n);
end
