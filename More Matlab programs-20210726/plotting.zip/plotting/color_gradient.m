function colors = color_gradient(start, stop, n)
% Return a color gradient from start to stop, in n steps.

    colors = zeros(n, 3);
    for k = 1:3
        colors(:,k) = linspace(start(k), stop(k), n);
    end
end
