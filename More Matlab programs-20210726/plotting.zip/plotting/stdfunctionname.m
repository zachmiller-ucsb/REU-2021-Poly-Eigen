function name = stdfunctionname(f)
% Return the name of a function, including any fixed parameters.

    if iscell(f)
        functionname = functions(f{1}).function;
        parameters = f{2};
        parameternames = '';
        for k = 1:length(parameters)
            parameternames = ...
                strcat(parameternames, '_', string(parameters(k)));
        end
        name = char(strcat(functionname, parameternames));
    else
        name = functions(f).function;
    end
end
