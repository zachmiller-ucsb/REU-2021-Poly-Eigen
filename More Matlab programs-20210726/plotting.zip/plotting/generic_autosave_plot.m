function generic_autosave_plot(scattercolorizer, ...
    plotfontsize, plottitle, ...
    experiment, degreerange, nodegen, ...
    polygen, evgen, boundgens, bound_data, ratio_data, figurepath)
% Perform a generic plot of the data given, for every nonempty subset of
% bounds, and save all the figures.

    numbounds = length(boundgens);
    for k = 1:numbounds
        kbounds = nchoosek(1:numbounds, k);
        for j = 1:size(kbounds, 1)
            boundindices = kbounds(j, :);
            theseboundgens = cell(k);
            thesebound_data = zeros(k, 2, max(degreerange));
            for i = 1:k
                theseboundgens{i} = boundgens{boundindices(i)};
                thesebound_data(i,:,:) = bound_data(boundindices(i),:,:);
            end
            generic_plot(scattercolorizer, plotfontsize, plottitle, ...
                experiment, degreerange, nodegen, polygen, ...
                evgen, theseboundgens, thesebound_data, ratio_data, ...
                figurepath);
            figurename = stdautosavename(figurepath, experiment, ...
                degreerange, nodegen, polygen, evgen, boundindices);
            saveas(gcf, join([figurename, '.fig'], ''));
            saveas(gcf, join([figurename, '.png'], ''));
        end
    end
end
