function colors = plotscatter_grad_blue2x(n)
% Return a color gradient from start to stop, in n steps.

    blue = [0 0 1];
    lightblue = [29 67 78] / 78;

    colors = [ ...
        color_gradient(blue, lightblue, floor(n/2))' ...
        color_gradient(blue, lightblue, ceil(n/2))' ...
    ]';
end
