function generic_plot(scattercolorizer, plotfontsize, plottitle, ...
    experiment, degreerange, nodegen, ...
    polygen, evgen, boundgens, bound_data, ratio_data, ~)
% Plot the collected data given by the arguments.

    figure;
    hold on;

    % make larger
    position = get(gcf, 'Position');
    position(3) = 1024;
    position(4) = 768;
    set(gcf, 'Position', position);

    xlabel('degree');
    ylabel('k ratio');
    set(gca, "yscale", "log");
    set(gca, "FontSize", plotfontsize);
    axis tight

    numbounds = length(boundgens);
    legends = cell(numbounds * 2 + 1, 1);

    degreedim = size(degreerange);
    boundsrange = 1:numbounds;
    plottedbounds = 0;

    for k = boundsrange
        boundgenname = stdfunctiondisplayname(boundgens{k});

        upperbound = reshape(bound_data(k, 1, degreerange), degreedim);
        if min(upperbound) < Inf
            plottedbounds = plottedbounds + 1;
            legends{plottedbounds} = boundgenname;
            semilogy(degreerange, upperbound, '^-', ...
                'Series', k, 'LineWidth', 2+numbounds-k);
        end

        lowerbound = reshape(bound_data(k, 2, degreerange), degreedim);
        if max(lowerbound) > -Inf
            plottedbounds = plottedbounds + 1;
            legends{plottedbounds} = boundgenname;
            semilogy(degreerange, lowerbound, 'v-', ...
                'Series', k, 'LineWidth', 2+numbounds-k);
        end
    end

    legends = legends(1:plottedbounds + 1);
    legends{plottedbounds + 1} = 'k ratio';

    numratios = length(ratio_data);
    scatterdatax = [];
    scatterdatay = [];
    scattercolors = [];

    for k = 1:numratios
        kratios = double(ratio_data{k});
        numkratios = length(kratios);
        if numkratios > 0
            kratios_x = ones(1, numkratios) * k;
            scatterdatax = [scatterdatax kratios_x];
            scatterdatay = [scatterdatay kratios];
            kratiocolors = scattercolorizer(numkratios);
            scattercolors = [scattercolors kratiocolors'];
        end
    end
    if ~ isempty(scatterdatax)
        scatter(scatterdatax, scatterdatay, 'CData', scattercolors');
    else
        legends = legends(1:plottedbounds);
    end

    legend(legends, 'Location', 'northwest');

    experimentname = stdfunctiondisplayname(experiment);
    nodegenname = stdfunctiondisplayname(nodegen);
    polygenname = stdfunctiondisplayname(polygen);
    evgenname = stdfunctiondisplayname(evgen);

    if plottitle
        title(['Condition Number Ratio (', ...
            experimentname, ', ', nodegenname, ', ', ...
            polygenname, ', ', evgenname, ')']);
    end

    hold off;
end
