function name = stdfunctiondisplayname(f)
% Return the name of a function with underscores escaped.

    name = replace(stdfunctionname(f), '_', '\_');
end
