function L = E1(P)
%L={L0,L1} is the pencil E1_P. L=la L1+L0
k = length(P)-1;
% if mod(k,2) == 1
%     return;
% end
n = size(P{1},1);
M1 = [];
for j = 1:k/2
    M1 = [M1;zeros(n,n*(j-1)) P{k-2*j+3} zeros(n,n*(k/2-j+1))];
end
M1 = [M1;zeros(n,n*k/2) -P{1}]; 
%disp(M1);
M0 = [];
for j = 1:k/2-1
    M0 = [M0;zeros(n,n*(j-1)) P{k-2*j+2} zeros(n,n*(k/2-j+1))];
end
M0 = [M0;zeros(n,n*(k/2-1)) P{2} P{1};zeros(n,n*(k/2-1)) P{1} zeros(n,n)];
%disp('');
%disp(M0);

s = (k-2)/2;
J1 = [zeros(s,1) eye(s)];
J0 = [-eye(s) zeros(s,1)];
K1 = kron(J1,eye(n));
K0 = kron(J0,eye(n));
L1 = [M1 [K1'; zeros(n,s*n)];K1 zeros(s*n,n*(s+1))];
L0 = [M0 [K0'; zeros(n,s*n)];K0 zeros(s*n,n*(s+1))];
L = {L0,L1};
% disp(L1);
% disp(L0);
end


