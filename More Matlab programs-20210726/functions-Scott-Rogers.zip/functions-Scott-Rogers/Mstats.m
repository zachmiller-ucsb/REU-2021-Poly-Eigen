norms = zeros(1,20);
normaves = zeros(1,14);
for i = 4:2:30
    for j = 1:20
        [~,~,norms(j)] = Mcond(i,3,10);
    end
    normaves(i/2-1) = sum(norms)/20;
    disp(['Average norm for k = ',num2str(i),':']);
    disp(normaves(i/2-1));
end
plot(normaves);