function [M] = makeM(P)
k = length(P)-1;
for i = 1:k+1
    P{i} = double(P{i});
end
n = size(P{1},1);
M = eye(n*(k/2+1));
M = [M;zeros(n*(k/2-1),n*(k/2+1))];
for j = 1:k/2-1
    col = zeros(n*j,n);
    for l = k-2*j+1:-1:1
        col = [col;P{l}];
    end
    col = [col;zeros(n*(j-1),n)];
    M = [M col];
end

end

