function P = genP(k,n,r)
    P = cell(1,k+1);
    for i = 1:k+1 %enters random nxn matrices with entries [-10,10] for A_0 to A_{k-1}
        P{i} = sym(-r + (2*r)*rand(n),'f');
    end
    