function [ Nq, E,D, e] = etatRatio(P, Lq, Q, gamma)
%ETATRATIO returns list of np/nl in order for sorted eigenvalues (sorted by
%ascending magnitude) when P is not scaled.
    k = length(P) - 1;
    n = size(P{1},1);

    %Np = zeros(1,n*k);
    Nq= zeros(1,n*k);
    E= zeros(1, n*k);
 
    
    [V1,D] = polyeig(Lq{1},Lq{2}); %V1: eigenvectors; D: eigenvalues; sin escalar.
    [~, I] = sort(abs(D));
    D = D(I);
    V1 = V1(:,I');
   
    
    
    for i=1:length(D)
        e = D(i);
        x1 = V1(:,i);
        %x3=V2(:,i);
        %e4=D2(i);
        e3=gamma*e;
        %nlp = berror(Lp,x1,e);   %backward error of Lp
        nlq = berror(Lq,x1,e);  %backward error of Lq
        
        if abs(e) > 1
            x2 = V1(1: n,i);
            %x2=V1(n+1:2*n,i);
            %x2=e^{k-1)*V1(2*n+1:3*n,i);
         
            %x4= V2(1:n,i);%recovery of eigenvector for P
        else
            x2 = V1(n*(k-1)+1: n*(k),i);
            %x4= V2(n*(k-1)+1:n*k, i);
        end
        
        %np1 = berror(P,x2,e);
        np2= berror(P,x2,e3);
        %backward error of P
        
        %Np(i) = np1/nlp;
        Nq(i)=np2/nlq;
        E(i)=norm(x1)/norm(x2); % quotient of norm of eigenvector of L and norm of eigenvector of P
       
    end
    
 
  % [n, I]=max(Nq);
   e=max(E(I));
   
  