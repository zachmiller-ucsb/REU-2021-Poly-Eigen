%%% Consideramos el polinomio en relative-pose-5pt, el cual tiene leading
%%% coefficient singular, y calculamos las normas de los coeficientes, y
%%% las tropical roots. 

function [Pr, gamma, normasr]=tropicalp(r)

digits(16);
                  tic
       
            %P = genP(k,n,10);
            k = 3;
            n = 128;
            P = nlevp('plasma_drift');
            
            normas=zeros(4,1);
           
            for i = 0:k
                P{i+1} = vpa(P{i+1});
                normas(i+1)=norm(P{i+1})
            end
          S=max(normas);
          %log(normas)
         % x=[0;1;2;3]; y=log(normas);
         % plot(0:3,log( normas), '*')
          %puntos=convhull(x,y);  %calculamos el convex hull
          
         %hold on
         %plot(x(puntos), y(puntos),'-r'), hold off
         
          
          % In this case, the upper boundary of the newton polygon contains all pairs of the form
          % (i, log(norma(i))). Thus, the tropical polynomial (norma(A0),
          % norma(A1)la, norma(A2) la^2, norma(A3)la^3) has three tropical
          % roots of multiplicity 1 that we give next.
          m=zeros(1,2);
          troproots=zeros(1,2);
          
              troproots(1)=normas(1)/normas(2);
              troproots(2)=(normas(2)/normas(4))^(1/2);
        
          
         % Next we compute the scaling parameters.
         
         ka=[0,1,3];
          beta=zeros(1,2);
          
            
                beta(1)=(normas(1)*troproots(1)^ka(1))^(-1);
                beta(2)=(normas(2)*troproots(2)^ka(2))^(-1);
            
            %normas;  ka;  troproots;  beta;
            normasr=cell(1,4);
            
            if r==0
                for i=1:4
                    Pr{i}=P{i};
                    normasr{i}=vpa(norm(Pr{i}));
                    %beta=1;
                    gamma=1;
                end
                
            elseif  r==1
                for i=1:4
                    Pr{i}=P{i}/S;
                    normasr{i}=vpa(norm(Pr{i}));
                    %beta=1/S;
                    gamma=1;
                end
                
            elseif r==2     
          for i=1:4
                Pr{i}=beta(1)*troproots(1)^(i-1)*P{i};
                normasr{i}=vpa(norm(Pr{i}));
                %beta=beta(1);
                gamma=troproots(1);
          end
            
            elseif r==3
       
            for i=1:4
                Pr{i}=beta(2)*troproots(2)^(i-1)*P{i};
                normasr{i}=vpa(norm(Pr{i}));
                %beta=beta(2);
                gamma=troproots(2);
            end
            
            
         end   
            troproots, beta