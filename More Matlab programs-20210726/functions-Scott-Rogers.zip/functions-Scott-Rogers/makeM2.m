function [M2] = makeM2(P)
k = length(P)-1;
n = size(P{1},1);
M1 = makeM(P);

% make R

R = zeros(n*k);
for i = 1:k
    R(n*(i-1)+1:n*i,n*(k-i)+1:n*(k-i+1)) = eye(n);
end

% make Pi1B and Pi2

Pi1B = zeros(n*k);
for i = 1:k/2
    Pi1B(n*(i-1)+1:n*i,n*(2*i-2)+1:n*(2*i-1)) = eye(n);
end
Pi1B(n*(k/2)+1:n*(k/2+1),n*(k-1)+1:n*k) = eye(n);
for i = 1:k/2-1
    Pi1B(n*(k/2+i)+1:n*(k/2+i+1),n*(2*i-1)+1:n*2*i) = eye(n);
end

Pi2 = zeros(n*k);
Pi2(1:n,1:n) = eye(n);
for i = 2:k/2+1
    Pi2(n*(2*i-3)+1:n*(2*i-2),n*(i-1)+1:n*i) = eye(n);
end
for i = 2:k/2
    Pi2(n*(2*i-2)+1:n*(2*i-1),n*(k/2+i-1)+1:n*(k/2+i)) = eye(n);
end

% make D

D = eye(n*k);
for i = 2:2:k/2-2
    D(n*(i-1)+1:n*i,n*(i-1)+1:n*i) = -eye(n);
end

M2 = R*M1*Pi1B*D*R*Pi2;

end

