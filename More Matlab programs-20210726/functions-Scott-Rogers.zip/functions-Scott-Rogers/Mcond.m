function [M,c,nor] = Mcond(k,n,r)
P = genP(k,n,r);
%P{1} = eye(n);
for i = 1:k+1
    X{i} = norm(vpa(P{i}));
end
% for i = 0:k
%     disp(['||A_',num2str(i),'|| = ']);
%     disp(vpa(X{i+1}));
% end
m = vpa(max([X{:}]));
Ps = cellfun(@(x) x/m,P,'un',0);
%Ps{1} = eye(n);
M = eye(n*(k/2+1));
M = [M;zeros(n*(k/2-1),n*(k/2+1))];
for j = 1:k/2-1
    col = zeros(n*j,n);
    for l = k-2*j+1:-1:1
        col = [col;-Ps{l}];
    end
    col = [col;zeros(n*(j-1),n)];
    M = [M col];
end

c = cond(M);
nor = norm(M);
% disp('Matrix M Condition Number (scaled):');
% disp(cond(M));
% disp('Matrix M Norm (scaled):');
% disp(norm(M));
% 
% disp('Determinant of A_0:');
% disp(det(Ps{1}));
% disp('Determinant of A_k:');
% disp(det(Ps{k+1}));
% M = eye(n*(k/2+1));
% M = [M;zeros(n*(k/2-1),n*(k/2+1))];
% for j = 1:k/2-1
%     col = zeros(n*j,n);
%     for l = k-2*j+1:-1:1
%         col = [col;P{l}];
%     end
%     col = [col;zeros(n*(j-1),n)];
%     M = [M col];
% end
% 
% disp('Matrix M Condition Number (unscaled):');
% disp(cond(M));

end

