function [D,P] = testR(P,k,n)
% test(i) performs backward error on random matrix 
%polynomials of degree k and size n. 
  
    %First test D(0), i = 0, varying j
    %close all
        digits(40);
        figure
        
           tic
          
            %P = genP(k,n,100);
            
  %Conditioning           
          
  %Backward error           
    r=0;        
           [Q,gamma, normas]=tropicalr(r, P,n,k) ; 
            
           rop=1;
             for i=1:k+1
            rop=max(rop,norm(Q{i}));
             end
             d=min(norm(Q{1}), norm(Q{k+1}));
           
           rop=rop^2/d;
           
           ro=0;
           for i=1:k+1
               ro=max(ro, norm(Q{i}));
           end
           ro=ro/d;
           
            for i=1:k+1
                P{i}=double(P{i});
                %Q{i}=double(Q{i}); %scaled polynomial
            end
            % Modify norm of A_0. 
             % P{k}=10^4*P{k};
             
             
            % Test T_P (Mackey pencil)

            disp('Loading results for T_p...');
            [L1,L0] = T(k);
            [nL1,nL0] = fillGFP(L1,L0,Q); % uses the matrices in Q to form T_q
            Lq = {-nL0,nL1}; 
            
            %[Y1,E,D] = tRatio(L,P); %computes quotients of condition numbers
            
         
                
           
            [ N1q, E1, D1, e1] = etatRatio1(P, Lq,Q,gamma);   %computes quotients of backward errors.
            %semilogy(E1,vpa(Y1),'-*');
            %N1p=N1p(1:10);
            %N1q=N1q(1:10);
            %hold on;
            
           % [ro, ro1,rop,bTc, bDc, bCc, X] = getBoundsall(P,'T');
            
            bTb=4*k^(3/2)*rop*e1;
            
     
            %Test D_1 from DLP
            disp('Loading results for D1 in DLP...');
            [L1,L0] = DLP(k,1);
            [nL1,nL0] = fillFPR(L1,L0,Q);
            Lq = {-nL0,nL1};         
            %[mL1, mL0]=fillFPR(L1, L0, Q);
            %Lq={-mL0, mL1};
            %[Y2,~,~,~] = hRatio(k-1,L,P,'DLP');
            
           [N2q, E2, D2, e2] = etaRatio(P, Lq, Q, gamma,k-1);
           
            bDb=k^(3/2)*ro*e2;
            %N2p=N2p(1:10)
            %N2q=N2q(1:10);
            %semilogy(E,vpa(Y2),'-o');
            %hold on;
            
            
            
            %Test D_k from DLP
           disp('Loading results for Dk in DLP...');
            [L1,L0] = DLP(k,k);
            [nL1,nL0] = fillFPR(L1,L0,Q);
            Lq = {-nL0,nL1};    
            %[mL1, mL0]=fillFPR(L1, L0, Q);
            %Lq={-mL0, mL1};
           % [Y3,~,~,~] = hRatio(0,L,P,'DLP'); 
         
           [ N3q ,E3, D3, e3] = etaRatio(P, Lq, Q, gamma, 0);
          
            
           bDkb=k^(3/2)*ro*e3;
            % Test C1

            disp('Loading results for C1...');
            [L1,L0] = C(k);
            [nL1,nL0] = fillFPR(L1,L0,Q);
            Lq= {-nL0,nL1};
            %[mL1,mL0] = fillFPR(L1,L0,Q);
            %Lq = {-mL0,mL1};
            %[Y4,E,D] = tRatio(L,P); 
      
           [ N4q, E4, D4, e4]=etatRatio1(P, Lq,Q, gamma);
            %N4 = etaRatioC(L,P);
            %semilogy(E,vpa(Y4),'-p');
            %N4p=N4p(1:10);
            %N4q=N4q(1:10);
            bCb=k^(5/2)*rop*e4;
            
            %UBc=max([eval(bTc), eval(bDc), eval(bCc)]);
           % LBc=1/UBc;

            %legend('T_P','D_1','D_k','C_1');
            
            %axis([0 n*k+1 1/(k*10) UBc*10]);
            %title('Condition number ratios comparison');
           
          subplot(1,2,r+1)
            E=1:n*k;
            %Backward error
          %figure;
            semilogy(E,vpa(N1q),'-*');
            hold on;
            semilogy(E,vpa(N2q),'-o');
            hold on;        
            semilogy(E,vpa(N3q),'-x');
            hold on;
            semilogy(E,vpa(N4q),'-p');
            hold on;
           
            %UBb=max([eval(bTb), eval(bDb),eval(bDkb), eval(bCb)]);
            %LBb=1/UBb;
            
            legend('T_P','D_1', 'D_k','C_1','location','best');
            %legend('location','best');
            title('Backward error ratios comparison - unscaled');
            %axis([0 n*k+1 1/(10*k) UBb*10]);
            drawnow;
      
            %Print information
            disp('SCALED RESULTS:');
            disp(['k = ',num2str(k)]);
            disp(['n = ',num2str(n)]);
            
            %disp('Largest |d| = ');
            %disp(vpa(abs(D(n*k))));
            %disp('Smallest |d| = ');
            %disp(vpa(abs(D(1))));
            
            for i = 0:k
                disp(['||A_',num2str(i),'|| = ']);
                disp(normas{i+1});
            end
            
           disp('rho = ');
           disp(vpa(ro));
           %disp('rho1 = ');
           %disp(vpa(ro1));
           %disp('rho2 = ');
           %disp(vpa(ro2));
            disp('rho'' = ');
            disp(vpa(rop));
            
            
            %disp(['Upper Bound for condition #, T_P: [',num2str(eval(bTc)),']']);
           % disp(['Upper Bound for condition #, D1, Dk: [',num2str(eval(bDc)),']']);
            %disp(['Upper Bound for condition #, C1: [',num2str(eval(bCc)),']']);
           disp(['Upper Bound for backward, T_P: [', num2str(eval(bTb)), ']']);
           disp(['Upper Bound for backward, D1: [', num2str(eval(bDb)), ']']);
            disp(['Upper Bound for backward, Dk: [', num2str(eval(bDkb)), ']']);
            disp(['Upper Bound for backward, C1: [', num2str(eval(bCb)), ']']);
            %disp(['Upper Bound for condition #, T_P: [',num2str(eval(bT)),',',num2str(eval(b2)),']']);
            %disp(['Bounds for backward error: [',num2str(eval(b1p)),',',num2str(eval(b2p)),']']);
            
            disp(['min. eta_P/eta_T: ', num2str(min(N1q))]);
            disp(['min. eta_P/eta_D1: ', num2str(min(N2q))]);
           disp(['min. eta_P/eta_Dk: ', num2str(min(N3q))]);
            disp(['min. eta_P/eta_C1: ', num2str(min(N4q))]);
            
            disp(['max. eta_P/eta_T: ', num2str(max(N1q))]);
            disp(['max. eta_P/eta_D1: ', num2str(max(N2q))]);
            disp(['max. eta_P/eta_Dk: ', num2str(max(N3q))]);
            disp(['max. eta_P/eta_C1: ', num2str(max(N4q))]);
            
           % disp(['min. kappa_T/kappa_P: ', num2str(min(real(eval(Y1))))]);
           % disp(['min. kappa_D1/kappa_P: ', num2str(min(real(eval(Y2))))]);
           % disp(['min. kappa_Dk/kappa_P: ', num2str(min(real(eval(Y3))))]);
           % disp(['min. kappa_C1/kappa_P: ', num2str(min(real(eval(Y4))))]);
            
           % disp(['max. kappa_T/kappa_P: ', num2str(max(real(eval(Y1))))]);
           % disp(['max. kappa_D1/kappa_P: ', num2str(max(real(eval(Y2))))]);
           % disp(['max. kappa_Dk/kappa_P: ', num2str(max(real(eval(Y3))))]);
           % disp(['max. kappa_C1/kappa_P: ', num2str(max(real(eval(Y4))))]);
                   
         r=1;        
           [Q,gamma, normas]=tropicalr(r, P,n,k) ; 
            
           rop=1;
             for i=1:k+1
            rop=max(rop,norm(Q{i}));
             end
             d=min(norm(Q{1}), norm(Q{k+1}));
           
           rop=rop^2/d;
           
           ro=0;
           for i=1:k+1
               ro=max(ro, norm(Q{i}));
           end
           ro=ro/d;
           
            for i=1:k+1
                P{i}=double(P{i});
                Q{i}=double(Q{i}); %scaled polynomial
            end
            % Modify norm of A_0. 
             % P{k}=10^4*P{k};
             
             
            % Test T_P (Mackey pencil)

            disp('Loading results for T_p...');
            [L1,L0] = T(k);
            [nL1,nL0] = fillGFP(L1,L0,Q); % uses the matrices in Q to form T_q
            Lq = {-nL0,nL1}; 
            
            %[Y1,E,D] = tRatio(L,P); %computes quotients of condition numbers
            
         
                
           
            [ N1q, E1, D1, e1] = etatRatio1(P, Lq,Q,gamma);   %computes quotients of backward errors.
            %semilogy(E1,vpa(Y1),'-*');
            %N1p=N1p(1:10);
            %N1q=N1q(1:10);
            %hold on;
            
           % [ro, ro1,rop,bTc, bDc, bCc, X] = getBoundsall(P,'T');
            
            bTb=4*k^(3/2)*rop*e1;
            
     
            %Test D_1 from DLP
            disp('Loading results for D1 in DLP...');
            [L1,L0] = DLP(k,1);
            [nL1,nL0] = fillFPR(L1,L0,Q);
            Lq = {-nL0,nL1};         
            %[mL1, mL0]=fillFPR(L1, L0, Q);
            %Lq={-mL0, mL1};
            %[Y2,~,~,~] = hRatio(k-1,L,P,'DLP');
            
           [N2q, E2, D2, e2] = etaRatio(P, Lq, Q, gamma,k-1);
           
            bDb=k^(3/2)*ro*e2;
            %N2p=N2p(1:10)
            %N2q=N2q(1:10);
            %semilogy(E,vpa(Y2),'-o');
            %hold on;
            
            
            
            %Test D_k from DLP
           disp('Loading results for Dk in DLP...');
            [L1,L0] = DLP(k,k);
            [nL1,nL0] = fillFPR(L1,L0,Q);
            Lq = {-nL0,nL1};    
            %[mL1, mL0]=fillFPR(L1, L0, Q);
            %Lq={-mL0, mL1};
           % [Y3,~,~,~] = hRatio(0,L,P,'DLP'); 
         
           [ N3q ,E3, D3, e3] = etaRatio(P, Lq, Q, gamma, 0);
          
            
           bDkb=k^(3/2)*ro*e3;
            % Test C1

            disp('Loading results for C1...');
            [L1,L0] = C(k);
            [nL1,nL0] = fillFPR(L1,L0,Q);
            Lq= {-nL0,nL1};
            %[mL1,mL0] = fillFPR(L1,L0,Q);
            %Lq = {-mL0,mL1};
            %[Y4,E,D] = tRatio(L,P); 
      
           [ N4q, E4, D4, e4]=etatRatio1(P, Lq,Q, gamma);
            %N4 = etaRatioC(L,P);
            %semilogy(E,vpa(Y4),'-p');
            %N4p=N4p(1:10);
            %N4q=N4q(1:10);
            bCb=k^(5/2)*rop*e4;
            
            %UBc=max([eval(bTc), eval(bDc), eval(bCc)]);
           % LBc=1/UBc;

            %legend('T_P','D_1','D_k','C_1');
            
            %axis([0 n*k+1 1/(k*10) UBc*10]);
            %title('Condition number ratios comparison');
           
          subplot(1,2,r+1)
            E=1:n*k;
            %Backward error
          %figure;
            semilogy(E,vpa(N1q),'-*');
            hold on;
            semilogy(E,vpa(N2q),'-o');
            hold on;        
            semilogy(E,vpa(N3q),'-x');
            hold on;
            semilogy(E,vpa(N4q),'-p');
            hold on;
           
            %UBb=max([eval(bTb), eval(bDb),eval(bDkb), eval(bCb)]);
            %LBb=1/UBb;
            
            legend('T_P','D_1', 'D_k','C_1','location','best');
            %legend('location','best');
            title('Backward error ratios comparison -scaled');
            %axis([0 n*k+1 1/(10*k) UBb*10]);
            drawnow;
      
            %Print information
            disp('SCALED RESULTS:');
            disp(['k = ',num2str(k)]);
            disp(['n = ',num2str(n)]);
            
            %disp('Largest |d| = ');
            %disp(vpa(abs(D(n*k))));
            %disp('Smallest |d| = ');
            %disp(vpa(abs(D(1))));
            
            for i = 0:k
                disp(['||A_',num2str(i),'|| = ']);
                disp(normas{i+1});
            end
            
           disp('rho = ');
           disp(vpa(ro));
           %disp('rho1 = ');
           %disp(vpa(ro1));
           %disp('rho2 = ');
           %disp(vpa(ro2));
            disp('rho'' = ');
            disp(vpa(rop));
            
            
            %disp(['Upper Bound for condition #, T_P: [',num2str(eval(bTc)),']']);
           % disp(['Upper Bound for condition #, D1, Dk: [',num2str(eval(bDc)),']']);
            %disp(['Upper Bound for condition #, C1: [',num2str(eval(bCc)),']']);
           disp(['Upper Bound for backward, T_P: [', num2str(eval(bTb)), ']']);
           disp(['Upper Bound for backward, D1: [', num2str(eval(bDb)), ']']);
            disp(['Upper Bound for backward, Dk: [', num2str(eval(bDkb)), ']']);
            disp(['Upper Bound for backward, C1: [', num2str(eval(bCb)), ']']);
            %disp(['Upper Bound for condition #, T_P: [',num2str(eval(bT)),',',num2str(eval(b2)),']']);
            %disp(['Bounds for backward error: [',num2str(eval(b1p)),',',num2str(eval(b2p)),']']);
            
            disp(['min. eta_P/eta_T: ', num2str(min(N1q))]);
            disp(['min. eta_P/eta_D1: ', num2str(min(N2q))]);
           disp(['min. eta_P/eta_Dk: ', num2str(min(N3q))]);
            disp(['min. eta_P/eta_C1: ', num2str(min(N4q))]);
            
            disp(['max. eta_P/eta_T: ', num2str(max(N1q))]);
            disp(['max. eta_P/eta_D1: ', num2str(max(N2q))]);
            disp(['max. eta_P/eta_Dk: ', num2str(max(N3q))]);
            disp(['max. eta_P/eta_C1: ', num2str(max(N4q))]);
            
           % disp(['min. kappa_T/kappa_P: ', num2str(min(real(eval(Y1))))]);
           % disp(['min. kappa_D1/kappa_P: ', num2str(min(real(eval(Y2))))]);
           % disp(['min. kappa_Dk/kappa_P: ', num2str(min(real(eval(Y3))))]);
           % disp(['min. kappa_C1/kappa_P: ', num2str(min(real(eval(Y4))))]);
            
           % disp(['max. kappa_T/kappa_P: ', num2str(max(real(eval(Y1))))]);
           % disp(['max. kappa_D1/kappa_P: ', num2str(max(real(eval(Y2))))]);
           % disp(['max. kappa_Dk/kappa_P: ', num2str(max(real(eval(Y3))))]);
           % disp(['max. kappa_C1/kappa_P: ', num2str(max(real(eval(Y4))))]);
                   
             
       toc
     