function [L1,L0] = T(k)
%Returns the structure of the Generalized fiedler pencil T_P for k odd
    if mod(k,2)
        seq = -1:-2:-k;
        seq2 = 0:2:k-1;
        L1 = eye(k);
        L0 = eye(k);
        for i = 0:floor(k/2)
            L1 = pemOp(L1,seq(length(seq) - i));
            L0 = pemOp(L0,seq2(length(seq2) - i));
        end
    else
        seq = -1:-2:-k+1;
        seq2 = 0:2:k;
        L1 = eye(k);
        L0 = eye(k);
        for i = 0:k/2-1
            L1 = pemOp(L1,seq(length(seq) - i));
            L0 = pemOp(L0,seq2(length(seq2) - i));
        end
    end
end

