function [D,P] = condback(k,n)
% computes both quotients of backward and condition numbers for random
% polynomial of size n and degree k.

    %First test D(0), i = 0, varying j
    close all
        digits(40);
        
           tic
 % Conditioning: Unscaled case          
            P = genP(k,n,50);
            
            %for i=1:4
                %P{i}=double(P{i});
            %    Q{i}=double(P{i});
            %end
            % Modify norm of A_0. 
             % P{k}=10^4*P{k};
             
          %rop=1;
           %  for i=1:k+1
           % rop=max(rop,norm(P{i}));
           %  end
           %  d=min(norm(P{1}), norm(P{k+1}));
           
          % rop=rop^2/d;
          % ro1=rop^3/d;
           
          % ro=0;
          % for i=1:k+1
          %     ro=max(ro, norm(P{i}));
          % end
          % ro=ro/d; 
           
          % rop=vpa(rop);
          % ro1=vpa(ro1);
          % ro=vpa(ro);
           
           
           
            % Test T_P (Mackey pencil)

            disp('Loading results for E2...');
            L = T(P);
%             [nL1,nL0] = fillGFP(L1,L0,P); % uses the matrices in P to form T_P
%             L = {-nL0,nL1};
            
            [Y1,E,D] = tRatio(L,P); %computes quotients of condition numbers
            
         
                
          
            %[N1, E1, D1, e1] = etatRatio(L,P,0);   %computes quotients of backward errors.
            
            
            [ro, ro1,rop,bTc, bDc, bCc, X] = getBoundsall(P,'T');
            
            %bTc=2*k^(3)*ro1;
            
     
            %Test D_1 from DLP
            disp('Loading results for D1 in DLP...');
            [L1,L0] = DLP(k,1);
            [nL1,nL0] = fillFPR(L1,L0,P);
            L = {-nL0,nL1};              
            [Y2,~,~,~] = hRatio(k-1,L,P,'DLP');
            
           %[N2, E2, D2, e2] = etaRatio(L,P,k-1);
           
            %bDc=k^(2)*ro
            
            
            
            
            
            %Test D_k from DLP
            disp('Loading results for Dk in DLP...');
            [L1,L0] = DLP(k,k);
            [nL1,nL0] = fillFPR(L1,L0,P);
            L = {-nL0,nL1};              
            [Y3,~,~,~] = hRatio(0,L,P,'DLP'); 
         
           %[ N3,E3, D3, e3] = etaRatio(L,P,0);
            
            
           %bDkc=k^(2)*ro;
            % Test C1

            disp('Loading results for C1...');
            [L1,L0] = C(k);
            [nL1,nL0] = fillFPR(L1,L0,P);
            L = {-nL0,nL1};
            
            [Y4,E,D] = tRatio(L,P); 
      
          % [ N4, E4, D4, e4]=etatRatio(L,P,1);
            %N4 = etaRatioC(L,P);
            
            
            %bCc=2*sqrt(2)*k^(3)*rop;
            
            %UBc=max([eval(bTc), eval(bDc), eval(bCc)]);
            %LBc=1/UBc;
            subplot(1,2,1)
            %figure
            semilogy(E,vpa(Y1),'-*');
            hold on;
            semilogy(E,vpa(Y2),'-o');
            hold on;
            semilogy(E,vpa(Y3),'-x');
            hold on;
            semilogy(E,vpa(Y4),'-p')
            
            legend('T_P','D_1','D_k','C_1','location','best');
            %legend('position', 'best');
            
            %axis([0 n*k+1 1/(k*10) UBc*10]);
            title('Condition number ratios comparison-unscaled');
            
            %Backward error
            %figure;
            %semilogy(E,vpa(N1),'-*');
           % hold on;
          %  semilogy(E,vpa(N2),'-o');
           % hold on;        
           % semilogy(E,vpa(N3),'-x');
           % hold on;
          %  semilogy(E,vpa(N4),'-p');
          %  hold on;
           
           % UBb=max([eval(bTb), eval(bDb),eval(bDkb), eval(bCb)]);
           % LBb=1/UBb;
            
           
            %Print information
            disp('UNSCALED RESULTS:');
            disp(['k = ',num2str(k)]);
            disp(['n = ',num2str(n)]);
            
            disp('Largest |d| = ');
            disp(vpa(abs(D(n*k))));
            disp('Smallest |d| = ');
            disp(vpa(abs(D(1))));
            
             X = cell(1,k+1);
        for i = 1:k+1
            P{i} = vpa(P{i});
            X{i} = norm(P{i});
        end
            
            for i = 0:k
                disp(['||A_',num2str(i),'|| = ']);
                disp(vpa(X{i+1}));
            end
            
            disp('rho = ');
            disp(vpa(ro));
            disp('rho1 = ');
            disp(vpa(ro1));
            %disp('rho2 = ');
            %disp(vpa(ro2));
            disp('rho'' = ');
            disp(vpa(rop));
            
            
            disp(['Upper Bound for condition #, T_P: [',num2str(eval(bTc)),']']);
            disp(['Upper Bound for condition #, D1, Dk: [',num2str(eval(bDc)),']']);
            disp(['Upper Bound for condition #, C1: [',num2str(eval(bCc)),']']);
            %disp(['Upper Bound for backward, T_P: [', num2str(eval(bTb)), ']']);
            %disp(['Upper Bound for backward, D1: [', num2str(eval(bDb)), ']']);
           % disp(['Upper Bound for backward, Dk: [', num2str(eval(bDkb)), ']']);
            %disp(['Upper Bound for backward, C1: [', num2str(eval(bCb)), ']']);
            %disp(['Upper Bound for condition #, T_P: [',num2str(eval(bT)),',',num2str(eval(b2)),']']);
            %disp(['Bounds for backward error: [',num2str(eval(b1p)),',',num2str(eval(b2p)),']']);
            
           % disp(['min. eta_P/eta_T: ', num2str(min(N1))]);
           % disp(['min. eta_P/eta_D1: ', num2str(min(N2))]);
           % disp(['min. eta_P/eta_Dk: ', num2str(min(N3))]);
           % disp(['min. eta_P/eta_C1: ', num2str(min(N4))]);
            
           % disp(['max. eta_P/eta_T: ', num2str(max(N1))]);
           % disp(['max. eta_P/eta_D1: ', num2str(max(N2))]);
            %disp(['max. eta_P/eta_Dk: ', num2str(max(N3))]);
           % disp(['max. eta_P/eta_C1: ', num2str(max(N4))]);
            
            disp(['min. kappa_T/kappa_P: ', num2str(min(real(eval(Y1))))]);
            disp(['min. kappa_D1/kappa_P: ', num2str(min(real(eval(Y2))))]);
            disp(['min. kappa_Dk/kappa_P: ', num2str(min(real(eval(Y3))))]);
            disp(['min. kappa_C1/kappa_P: ', num2str(min(real(eval(Y4))))]);
            
            disp(['max. kappa_T/kappa_P: ', num2str(max(real(eval(Y1))))]);
            disp(['max. kappa_D1/kappa_P: ', num2str(max(real(eval(Y2))))]);
            disp(['max. kappa_Dk/kappa_P: ', num2str(max(real(eval(Y3))))]);
            disp(['max. kappa_C1/kappa_P: ', num2str(max(real(eval(Y4))))]);
                   
            
       
          
       %----SCALED VERSION------
       %figure;
       disp('Producing scaled results...');
       
       m = vpa(max([X{:}]));
       Ps = cellfun(@(x) x/m,P,'un',0);
       
       %rop=1;
          %   for i=1:k+1
          %  rop=max(rop,norm(Ps{i}));
           %  end
           %  d=min(norm(Ps{1}), norm(Ps{k+1}));
           
          % rop=rop^2/d;
          % ro1=rop^3/d;
           
          % ro=0;
          % for i=1:k+1
          %     ro=max(ro, norm(Ps{i}));
          % end
           %ro=ro/d;  
           
       %Test T----
       
            disp('Loading results for T...');
            [L1,L0] = T(k);
            [nL1,nL0] = fillGFP(L1,L0,Ps);
            L = {-nL0,nL1};
            
            [Y1,E,D] = tRatio(L,Ps); 
            %[N1, E1, D1, e1]  = etatRatio(L,P);
            
            
           
            [ro, ro1,rop,bTc,bDc,bCc,X] = getBoundsall(Ps,'Ts');
            % bTc=2*k^(3)*ro1;
            %Test D_1 from DLP
            disp('Loading results for D1 in DLP...');
            [L1,L0] = DLP(k,1);
            [nL1,nL0] = fillFPR(L1,L0,Ps);
            L = {-nL0,nL1};              
            [Y2,~,~,~] = hRatio(k-1,L,Ps,'DLP');
            %[N2, E2, D2, e2] = etaRatio(L,P,k-1);
        
            % bDc=k^(2)*ro;

            
            
            %Test D_k from DLP
            disp('Loading results for Dk in DLP...');
            [L1,L0] = DLP(k,k);
            [nL1,nL0] = fillFPR(L1,L0,Ps);
            L = {-nL0,nL1};              
            [Y3,~,~,~] = hRatio(0,L,Ps,'DLP'); 
            %[N3, E3, D3, e3] = etaRatio(L,P,0);
            hDkc=k^(2)*ro;
            
            
            % Test C1

            disp('Loading results for C1...');
            [L1,L0] = C(k);
            [nL1,nL0] = fillFPR(L1,L0,Ps);
            L = {-nL0,nL1};
            
            [Y4,E,D] = tRatio(L,Ps); 
            %[N4,E4, D4, e4] = etatRatio(L,P);
           % bCc=2*sqrt(2)*k^(3)*rop;
            
            
            
            subplot(1,2,2)
            %figure
            semilogy(E,vpa(Y1),'-*');
            hold on;
            semilogy(E,vpa(Y2),'-o');
            hold on;
            semilogy(E,vpa(Y3),'-x');
            hold on;
            semilogy(E,vpa(Y4),'-p');
            legend('T_P','D_1','D_k','C_1','location', 'best');
            %axis([0 n*k+1 1/(10*k) UBc*10]);
            title('Condition number ratios comparison - scaled');
            drawnow;
            
            
            
                        %Print information
            disp('SCALED RESULTS:');
            disp(['k = ',num2str(k)]);
            disp(['n = ',num2str(n)]);
            
            disp('Largest |d| = ');
            disp(vpa(abs(D(n*k))));
            disp('Smallest |d| = ');
            disp(vpa(abs(D(1))));
            
             X = cell(1,k+1);
        for i = 1:k+1;
            Ps{i} = vpa(Ps{i});
            X{i} = norm(Ps{i});
            
        end
            
            for i = 0:k
                disp(['||A_',num2str(i),'|| = ']);
                disp(vpa(X{i+1}));
            end
            
            disp('rho =');
            disp(vpa(ro));
            disp('rho1 = ');
            disp(vpa(ro1));
            %disp('rho2 = ');
            %disp(vpa(ro2));
            disp('rho'' = ');
            disp(vpa(rop));
            
            disp(['Upper Bound for condition #, T_P: [',num2str(eval(bTc)),']']);
            disp(['Upper Bound for condition #, D1, Dk: [',num2str(eval(bDc)),']']);
            disp(['Upper Bound for condition #, C1: [',num2str(eval(bCc)),']']);
            %disp(['Upper Bound for backward, T_P: [', num2str(eval(bTb)), ']']);
            %disp(['Upper Bound for backward, D1: [', num2str(eval(bDb)), ']']);
           % disp(['Upper Bound for backward, Dk: [', num2str(eval(bDkb)), ']']);
            %disp(['Upper Bound for backward, C1: [', num2str(eval(bCb)), ']']);
            
           % disp(['min. eta_P/eta_T: ', num2str(min(N1))]);
           % disp(['min. eta_P/eta_D1: ', num2str(min(N2))]);
           % disp(['min. eta_P/eta_Dk: ', num2str(min(N3))]);
           % disp(['min. eta_P/eta_C1: ', num2str(min(N4))]);
            
           % disp(['max. eta_P/eta_T: ', num2str(max(N1))]);
           % disp(['max. eta_P/eta_D1: ', num2str(max(N2))]);
           % disp(['max. eta_P/eta_Dk: ', num2str(max(N3))]);
           % disp(['max. eta_P/eta_C1: ', num2str(max(N4))]);
            
            disp(['min. kappa_T/kappa_P: ', num2str(min(real(eval(Y1))))]);
            disp(['min. kappa_D1/kappa_P: ', num2str(min(real(eval(Y2))))]);
            disp(['min. kappa_Dk/kappa_P: ', num2str(min(real(eval(Y3))))]);
            disp(['min. kappa_C1/kappa_P: ', num2str(min(real(eval(Y4))))]);
            
            disp(['max. kappa_T/kappa_P: ', num2str(max(real(eval(Y1))))]);
            disp(['max. kappa_D1/kappa_P: ', num2str(max(real(eval(Y2))))]);
            disp(['max. kappa_Dk/kappa_P: ', num2str(max(real(eval(Y3))))]);
            disp(['max. kappa_C1/kappa_P: ', num2str(max(real(eval(Y4))))]);   
       toc
       
testR(P,k,n)
    

