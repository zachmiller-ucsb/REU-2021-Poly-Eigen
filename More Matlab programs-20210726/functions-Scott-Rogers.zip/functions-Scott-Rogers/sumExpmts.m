exps = 10;
n = 3;
k = 8;


P = genP(k,n,10);
m = vpa(max([X{:}]));
Ps = cellfun(@(x) x/m,P,'un',0);
L = E2(Ps);