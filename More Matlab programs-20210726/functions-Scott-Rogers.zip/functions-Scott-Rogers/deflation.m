function [N11, M11,VV,r] = deflation(N,M,tol)
%Deflation of infinite eigenvalues of index at most 1 of the pencil L(la)=la N- M
[m,n]=size(N);
[U,S,V]=svd(N);
s=diag(S);
r = sum(abs(s) > tol*norm(N));
N1=S(1:r,:)*V';
U2=U(:,r+1:n);
M2=U2'*M;

%Step 2
[UU,SS,VV]=svd(M2);
%UU*SS, VV
VV=VV(:,[n-r+1:n, 1:n-r]);
N11=VV'*N*VV
N11=N11(1:r, 1:r);
M11=VV'*M*VV
M11=M11(1:r,1:r);
end

