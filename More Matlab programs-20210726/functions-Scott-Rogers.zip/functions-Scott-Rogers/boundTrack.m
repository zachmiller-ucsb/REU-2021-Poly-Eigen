function [] = boundTrack(k,n,r)
P = genP(k,n,r);
for i = 1:k
    P{i} = P{k+1};
end
disp(P);
disp('First Step:');
L = E2(P);
[Y1,E,D,V] = e2Ratio(L,P);
disp(D);
disp(V);
a = zeros(k/2+1,1);
for i = 1:k/2+1
    a(i) = [abs(D(1))^(2*i-1)];
end
b = zeros(k/2-1,1);
for i = 1:k/2-1
    h = zeros(k-2*i+1,1);
    for j = 1:k-2*i+1
        h(j) = (abs(D(1))^(j-1))*norm(P{k+1-(j-1)});
    end
    b(i) = (abs(D(1)))^(2*i)*(sum(h)^2);
end
disp(sum(a)+sum(b));

end

