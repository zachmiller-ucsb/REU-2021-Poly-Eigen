function [M2b] = makeM2b(P)

k = length(P)-1;
n = size(P{1},1);
M1b = makeMb(P);

% make R

R = zeros(n*k);
for i = 1:k
    R(n*(i-1)+1:n*i,n*(k-i)+1:n*(k-i+1)) = eye(n);
end

% make Pi1B and Pi2

Pi1 = zeros(n*k);
for i = 1:k/2
    Pi1(n*(2*i-2)+1:n*(2*i-1),n*(i-1)+1:n*i) = eye(n);
end
Pi1(n*(k-1)+1:n*k,n*(k/2)+1:n*(k/2+1)) = eye(n);
for i = 1:k/2-1
    Pi1(n*(2*i-1)+1:n*2*i,n*(k/2+i)+1:n*(k/2+i+1)) = eye(n);
end

Pi2B = zeros(n*k);
Pi2B(1:n,1:n) = eye(n);
for i = 2:k/2+1
    Pi2B(n*(i-1)+1:n*i,n*(2*i-3)+1:n*(2*i-2)) = eye(n);
end
for i = 2:k/2
    Pi2B(n*(k/2+i-1)+1:n*(k/2+i),n*(2*i-2)+1:n*(2*i-1)) = eye(n);
end

% make D

D = eye(n*k);
for i = 2:2:k/2-2
    D(n*(i-1)+1:n*i,n*(i-1)+1:n*i) = -eye(n);
end

disp(Pi2B);
disp(Pi1);

M2b = Pi2B*R*D*Pi1*M1b*R;
end

