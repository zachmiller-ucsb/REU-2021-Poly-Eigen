function [Np,r] = etaRatio(Lp, P,h)
%ETATRATIO returns list of np/nl in order for sorted eigenvalues (sorted by
%ascending magnitude).
    k = length(P) - 1;
    n = size(P{1},1);

    N = zeros(1,n*k);
    E= zeros(1, n*n);
    %polyeig(P{:})
    [V1,D] = polyeig(double(Lp{1}),double(-Lp{2}));
    [~, I] = sort(abs(D));
    D = D(I);
    V1 = V1(:,I');
    %[V2,D2] = polyeig(Lq{1},-Lq{2});
    %[~, J] = sort(abs(D2));
    %D2 = D2(J)
    %V2 = V2(:,J');
    R = zeros(n*k,1);
    
    for i=1:length(D)
        e = D(i);
        x1 = V1(:,i);
        %e3=D2(i);
        %x3=V2(:,i);
%        e4=gamma*e;
        nlp = berror(Lp,x1,e);
%        nlq= berror(Lq,x1,e);
        x2 = V1(n*(k-h-1)+1:n*(k-h),i);
        %x4=V2(n*(k-h-1)+1: n*(k-h),i);
        
        R(i) = norm(x1)/norm(x2);
        np1 = berror(P,x2,e);
%        np2=berror(P,x2,e4);
        
        Np(i) = np1/nlp;
 %       Np(i)=np2/nlq;
        E(i)=norm(x1)/norm(x2);
    end
    r = max(R);
    
   %[n, I]=max(N);
   e=max(E);
