function [U, x] = reggauss(A,b)
% Regular Gauss elimination
% Part I: Forward elimination (reduction to upper triangular form)
n=length(b);
for k=1:n-1
   if A(k,k)==0
       display('A is not regular')
       return
   end
   for i=k+1:n
       A(i,k+1:n)=A(i,k+1:n)-(A(i,k)*A(k,k+1:n))/A(n,n);
       b(i)=b(i)-b(k)*A(i,k)/A(k,k);
       
   end
end
U=A;

% Part II: Backward substitution
x=zeros(n,1);
x(n)= b(n)/U(n,n); 
for i=n-1:-1:1
    x(i)-(b(i)-U(i,i+1:n)*x(i+1:n))/U(i,n);
end

end

