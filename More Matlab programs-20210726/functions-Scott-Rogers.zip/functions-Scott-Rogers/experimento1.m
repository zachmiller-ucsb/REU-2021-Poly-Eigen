%% Experimento 1
function [] = experimento1(k,n)
%UNTITLED8 Summary of this function goes here
%   Detailed explanation goes here
 close all
        digits(40);
        
           tic
 % Conditioning: Unscaled case          
              P = genP(k,n,50);
              for l = 1:k+1
                          P{l} = P{l}+P{l}';
                 
              end   
               X = cell(1,k+1);
        for i = 1:k+1
            P{i} = vpa(P{i});
            X{i} = norm(P{i});
        end
            
            for i = 0:k
                disp(['||A_',num2str(i),'|| = ']);
                disp(vpa(X{i+1}));
            end
            
             disp('Producing scaled results...');
       
       m = vpa(max([X{:}]));
       Ps = cellfun(@(x) x/m,P,'un',0);
       disp('Determinant of A_k:');
       disp(vpa(det(Ps{k+1})));
       Z = cell(1,k+1);
        for i = 1:k+1
            Ps{i} = vpa(Ps{i});
            Z{i} = norm(Ps{i});
            
        end
        
         
       
       disp('Loading results for E2...');
            L = E2(Ps);
%             [nL1,nL0] = fillGFP(L1,L0,Ps);
%             L = {-nL0,nL1};
            
            [Y1,E,D] = e2Ratio(L,Ps); 
            [N1,r1] = e2BackRatio(L,P);
            L = {vpa(L{1}), vpa(L{2})};
    %k = length(P)-1; %degree of polynomial
    %n = size(P{1},1); %size of coefficients
   % E = 1:(n*k); %indices for eigenvalues
   % Y = zeros(1,n*k);
   % Y = sym(Y,'f');
   % N = zeros(1,n*k);
   % N = sym(N,'f');
     
   
   % [C1,iL1] = Cp(L); %Creates symbolic Cp for linearization with coefficients L
   % C1 = vpa(C1);
   % [V1,D1] = eig(C1); %Creates symbolic Vi and Di for Ci, Vi contains right eigvectors, (Wi left),
   % V1 = vpa(V1);
   % D = vpa(diag(D1));
   % [~,I] = sort(abs(D));
   % D = D(I);
  
            
            pivot = 1;
            while D(pivot) < 1
                pivot=pivot+1;
            end
            
            disp('Loading results for E1...');
            L = E1(Ps);
%             [nL1,nL0] = fillGFP(L1,L0,Ps);
%             L = {-nL0,nL1};
            
            %[Y7,E,D] = e1Ratio(L,Ps); 
            [N7,r7] = e1BackRatio(L,P);
            
            %ECondRatios = [Y1(1:pivot-1) Y7(pivot:n*k)];
          
            EBackRatios = [N1(1:pivot-1) N7(pivot:n*k)];
            
            figure
           semilogy(E,vpa(N1),'-*');
           hold on;
           semilogy(E,vpa(N7),'-p');
           hold on;
           semilogy(E,vpa(N2),'-o');
           hold on;        
           semilogy(E,vpa(N3),'-x');
           hold on;
           semilogy(E,vpa(N4),'-p');
           hold on;
           legend('E_2','E_1','location', 'best');
           %axis([0 n*k+1 1/(10*k) UBc*10]);
           title('Backwards error ratios comparison - scaled');
           drawnow;
           
           disp('SCALED RESULTS:');
            disp(['k = ',num2str(k)]);
            disp(['n = ',num2str(n)]);
            
            disp('Largest |d| = ');
            disp(vpa(abs(D(n*k))));
            disp('Smallest |d| = ');
            disp(vpa(abs(D(1))));
            
             for i = 0:k
                disp(['||A_',num2str(i),'|| = ']);
                disp(vpa(Z{i+1}));
            end
end

