n=5;
A0=rand(5);
A0=A0+A0';
A1= rand(5);
A1=A1+A1';
A2=rand(5);
A2=A2+A2';
[U,S, V]=svd(A2);
S(5,5)=10^(-6);
A2=U*S*U';
A3=zeros(5);
N=[A3 zeros(5) zeros(5);zeros(5) A1 eye(5); zeros(5) eye(5) zeros(5)];
M=[-A2 zeros(5) eye(5);zeros(5) -A0 zeros(5); eye(5) zeros(5)  zeros(5) ];
[N11, M11, V,r] = deflation(N, M, eps);
%EP=polyeig(A0, A1, A2, zeros(5))
[X, EL]=eig(M11, N11);
X=V*[X;zeros(3*n-r, 10)];
E=diag(EL);
nA0=norm(A0);
nA1=norm(A1);
nA2=norm(A2);
nN=norm(N);
nM=norm(M);
backP=[];
backL=[];

M11, N11
%( E(1)*N-M)*X(:,1)

%(A0+E(1)*A1+E(1)^2*A2)*X(n+1:2*n,1)
% (A0+E(1)*A1+E(1)^2*A2)*X(1:n,1)
 
   
% back=[back; norm((E(i)*N11-M11)*X(:, i))/(norm(X(:,i))*(abs(E(i))*nN+nM) )];   


 
 for i=1:10
 if  abs(E(i))>=1
     numP=norm((A0+E(i)*(E(i)*A2+A1))*X(n+1:2*n,i));
     numL=norm((E(i)*N-M)*X(:,i));
     denP=norm(X(1:n,i)*(nA0+abs(E(i))*(abs(E(i))*nA2+nA1)));
     %denP=norm(X(n+1:2*n,i))*max([nA0,nA1,nA2])*(1+abs(E(i))*(1+abs(E(i))));
      denL=norm(X(:,i))*(abs(E(i))*nN+nM);
     backP=[backP; numP/denP];
      backL=[backL; numL/denL];
 else
     numP=norm((A0+E(i)*(E(i)*A2+A1))*X(1:n,i));
     %denP=norm(X(1:n,i))*max([nA0,nA1,nA2])*(1+abs(E(i))*(1+abs(E(i))));
     denL=norm(X(:,i))*(abs(E(i))*nN+nM);
     numL=norm((E(i)*N-M)*X(:,i));
     denP=norm(X(1:n,i)*(nA0+abs(E(i))*(abs(E(i))*nA2+nA1)));
      backP=[backP; numP/denP];
      backL=[backL; numL/denL];
 end
 end
 backP, backL
 
 %D1=[zeros(5) A2; A2 A1];
 %D2=[A2 zeros(5); zeros(5) -A0];
 %[XD, ED]=eig(D2,D1);
 %ED=diag(ED);
 %nD1=norm(D1);
% nD2=norm(D2);
% backD=[];
% for i=1:10
 %    backD=[backD; norm((ED(i)*D1-D2)*XD(:, i))/(norm(XD(:,i))*(abs(ED(i))*nD1+nD2) )];
     