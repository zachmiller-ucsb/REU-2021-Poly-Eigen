%Matlab script for testing block-symmetric linearizations of degree-4
%matrix polynomials.

%Experiment: 'NLEVP' or 'random'
exp = 'NLEVP';  
%Weights: 
%'new' (Tisseur-Van Barel), 'coeff' (coefficientwise), 'norm' (normwise)
w = 'new';

disp('Matrix polynomial')
if strcmp(exp,'NLEVP')==1
    %There are three quartic polynomials in the NLEVP collection: mirror (9x9),
    %orr_sommerfeld (64x64), and planar_waveguide (129x129)
    coeff = orr_sommerfeld;
    P0 = coeff{1};
    P1 = coeff{2};
    P2 = coeff{3};
    P3 = coeff{4};
    P4 = coeff{5};
    n = size(P0,1);
elseif strcmp(exp,'random')==1    %Random matrix polynomial
    n = 100;
    P0 = 1e0*(randn(n)+sqrt(-1)*randn(n));
    P1 = 1e0*(randn(n)+sqrt(-1)*randn(n));
    P2 = 1e0*(randn(n)+sqrt(-1)*randn(n));
    P3 = 1e0*(randn(n)+sqrt(-1)*randn(n));
    P4 = 1e0*(randn(n)+sqrt(-1)*randn(n));
    [U,S,V]=svd(P4);
    S = diag(S);
    S(n-10+1:n)= 10.^(-(1:10));
    S = diag(S);
    P4 = U*S*V';
end
%% SCALING THE POLYNOMIAL
disp('Scaling')
n4 = norm(P4);
n3 = norm(P3);
n2 = norm(P2);
n1 = norm(P1);
n0 = norm(P0);
nmax = max([n0 n1 n2 n3 n4]);
P4 = P4/nmax;
P3 = P3/nmax;
P2 = P2/nmax;
P1 = P1/nmax;
P0 = P0/nmax;
n4 = norm(P4);
n3 = norm(P3);
n2 = norm(P2);
n1 = norm(P1);
n0 = norm(P0);
%% LINEARIZATIONS
disp('linearization')
o = zeros(n);
i = eye(n);
%(1) Tp for odd degree (with n extra eigenvalues at infinity
A1 = [P4 -i o o o; -i o o o o; o o P2 -i o; o o -i o o; o o o o P0];
B1 = [o o o o o; o o i o o; o i P3 o o; o o o o i; o o o i P1];
%(2) Tp even degree
A2 = [-inv(P4) o o o; o P2 -i o; o -i o o; o o o P0];
B2 = [o i o o; i P3 o o; o o o i; o o i P1];
%(3) Tp for odd degree + non-unitary deflation
A3 = [-P4 o o o; o P2 -i o; o -i o o; o o o P0];
B3 = [o P4 o o; P4 P3 o o; o o o i; o o i P1];
%(4) Tp for odd degree + unitary deflation
%V = qr([i;P4],0);
V = null([P4 -i]);
V11 = V(1:n,1:n);
V21 = V(n+1:2*n,1:n);
A4 = [-V21'*V11 o o o; o P2 -i o; o -i o o; o o o P0];
B4 = [o V21' o o; V21 P3 o o; o o o i; o o i P1];
%(5) Dk
A5 = [o o -P4 o; o -P4 -P3 o; -P4 -P3 -P2 o;o o o P0];
B5 = [o o o P4;o o P4 P3; o P4 P3 P2; P4 P3 P2 P1];

%% EIGENVALUE/EIGENVECTOR COMPUTATIONS
disp('eigenvalues/eigenvectors')
%(1) Tp for odd degree
[V1,e1] = eig(A1,-B1);
[e1,ind] = sort(diag(e1),'descend');
V1 = V1(:,ind);
e1 = e1(n+1:end);
V1 = V1(:,n+1:end);
%(2) Tp even degree
[V2,e2] = eig(A2,-B2);
[e2,ind] = sort(diag(e2),'descend');
V2 = V2(:,ind);
%(3) Tp for odd degree + non-unitary deflation
[V3,e3] = eig(A3,-B3);
[e3,ind] = sort(diag(e3),'descend');
V3 = V3(:,ind);
%(4) Tp for odd degree + unitary deflation
[V4,e4] = eig(A4,-B4);
[e4,ind] = sort(diag(e4),'descend');
V4 = V4(:,ind);
%(5) Dk
[V5,e5]=eig(A5,-B5);
[e5,ind] = sort(diag(e5),'descend');
V5 = V5(:,ind);
%% EIGENVECTORS RECOVERY
disp('recovery')
X1 = zeros(n,4*n);
X2 = zeros(n,4*n);
X3 = zeros(n,4*n);
X4 = zeros(n,4*n);
X5 = zeros(n,4*n);

%(1) Tp for odd degree
for i=1:4*n
    if abs(e1(i))<=1
        X1(:,i) = V1(4*n+1:5*n,i); %recover from last block
    else
        X1(:,i) = V1(1:n,i); %recover from first block
    end
end
%(2) Tp even degree
for i=1:4*n
    if abs(e4(i))<=1
        X2(:,i) = V2(3*n+1:4*n,i); %recover from last block
    else
        X2(:,i) = V2(n+1:2*n,i); %recover from second block
    end
end   
%(3) Tp for odd degree + non-unitary deflation
for i=1:4*n
    if abs(e3(i))<=1
        X3(:,i) = V3(3*n+1:4*n,i); %recover from last block
    else
        X3(:,i) = V3(n+1:2*n,i); %recover from second block
    end
end
%(4) Tp for odd degree + unitary deflation
for i=1:4*n
    if abs(e4(i))<=1
        X4(:,i) = V4(3*n+1:4*n,i); %recover from last block
    else
        X4(:,i) = V4(n+1:2*n,i); %recover from second block
    end
end
%(5) Dk
for i=1:4*n
    if abs(e5(i))<=1
        X5(:,i) = V5(3*n+1:4*n,i); %recover from last block
    else
        X5(:,i) = V5(1:n,i); %recover from first block
    end
end

%% BACKWARD ERRORS:
disp('backward errors')
b_error1 = zeros(1,4*n);
b_error2 = zeros(1,4*n);
b_error3 = zeros(1,4*n);
b_error4 = zeros(1,4*n);
b_error5 = zeros(1,4*n);
%(1) Tp odd degree

for i=1:4*n
    res = P4*e1(i)+P3;
    res = e1(i)*res+P2;
    res = e1(i)*res+P1;
    res = e1(i)*res+P0;
    r = res*X1(:,i);
    
    e = abs(e1(i));    
    if strcmp(w,'coeff')==1 
        w0 = n0;
        w1 = n1;
        w2 = n2;
        w3 = n3;
        w4 = n4;
    elseif strcmp(w,'new')==1 
        w = max([n0,n1*e,n2*e^2,n3*e^3,n4*e^4]);
        w0 = w;
        w1 = w/e;
        w2 = w/e^2;
        w3 = w/e^3;
        w4 = w/e^4;
    else
        w0 = 1;
        w1 = 1;
        w2 = 1;
        w3 = 1;
        w4 = 1;
    end
    poly = w4*e+w3;
    poly = e*poly+w2;
    poly = e*poly+w1;
    poly = e*poly+w0;
    b_error1(i)=norm(r)/(poly*norm(X1(:,i)));
end
%(2) Tp even degree
for i=1:4*n
    res = P4*e2(i)+P3;
    res = e2(i)*res+P2;
    res = e2(i)*res+P1;
    res = e2(i)*res+P0;
    r = res*X2(:,i);
    
    e = abs(e2(i));    
    if strcmp(w,'coeff')==1 
        w0 = n0;
        w1 = n1;
        w2 = n2;
        w3 = n3;
        w4 = n4;
    elseif strcmp(w,'new')==1 
        w = max([n0,n1*e,n2*e^2,n3*e^3,n4*e^4]);
        w0 = w;
        w1 = w/e;
        w2 = w/e^2;
        w3 = w/e^3;
        w4 = w/e^4;
    else
        w0 = 1;
        w1 = 1;
        w2 = 1;
        w3 = 1;
        w4 = 1;
    end
    poly = w4*e+w3;
    poly = e*poly+w2;
    poly = e*poly+w1;
    poly = e*poly+w0;
    b_error2(i)=norm(r)/(poly*norm(X2(:,i)));
end
%(3) Tp for odd degree + non-unitary deflation
for i=1:4*n
    res = P4*e3(i)+P3;
    res = e3(i)*res+P2;
    res = e3(i)*res+P1;
    res = e3(i)*res+P0;
    r = res*X3(:,i);
    
    e = abs(e3(i));    
    if strcmp(w,'coeff')==1 
        w0 = n0;
        w1 = n1;
        w2 = n2;
        w3 = n3;
        w4 = n4;
    elseif strcmp(w,'new')==1 
        w = max([n0,n1*e,n2*e^2,n3*e^3,n4*e^4]);
        w0 = w;
        w1 = w/e;
        w2 = w/e^2;
        w3 = w/e^3;
        w4 = w/e^4;
    else
        w0 = 1;
        w1 = 1;
        w2 = 1;
        w3 = 1;
        w4 = 1;
    end

    poly = w4*e+w3;
    poly = e*poly+w2;
    poly = e*poly+w1;
    poly = e*poly+w0;    
    b_error3(i)=norm(r)/(poly*norm(X3(:,i)));
end
%(4) Tp for odd degree + unitary deflation
for i=1:4*n
    res = P4*e4(i)+P3;
    res = e4(i)*res+P2;
    res = e4(i)*res+P1;
    res = e4(i)*res+P0;
    r = res*X4(:,i);
    
    e = abs(e4(i));    
    if strcmp(w,'coeff')==1 
        w0 = n0;
        w1 = n1;
        w2 = n2;
        w3 = n3;
        w4 = n4;
    elseif strcmp(w,'new')==1 
        w = max([n0,n1*e,n2*e^2,n3*e^3,n4*e^4]);
        w0 = w;
        w1 = w/e;
        w2 = w/e^2;
        w3 = w/e^3;
        w4 = w/e^4;
    else
        w0 = 1;
        w1 = 1;
        w2 = 1;
        w3 = 1;
        w4 = 1;
    end

    poly = w4*e+w3;
    poly = e*poly+w2;
    poly = e*poly+w1;
    poly = e*poly+w0;
    b_error4(i)=norm(r)/(poly*norm(X4(:,i)));
end
%(5) Dk
for i=1:4*n
    res = P4*e5(i)+P3;
    res = e5(i)*res+P2;
    res = e5(i)*res+P1;
    res = e5(i)*res+P0;
    r = res*X5(:,i);
    
e = abs(e5(i));    
    if strcmp(w,'coeff')==1 
        w0 = n0;
        w1 = n1;
        w2 = n2;
        w3 = n3;
        w4 = n4;
    elseif strcmp(w,'new')==1 
        w = max([n0,n1*e,n2*e^2,n3*e^3,n4*e^4]);
        w0 = w;
        w1 = w/e;
        w2 = w/e^2;
        w3 = w/e^3;
        w4 = w/e^4;
    else
        w0 = 1;
        w1 = 1;
        w2 = 1;
        w3 = 1;
        w4 = 1;
    end

    poly = w4*e+w3;
    poly = e*poly+w2;
    poly = e*poly+w1;
    poly = e*poly+w0;
    
    b_error5(i)=norm(r)/(poly*norm(X5(:,i)));
end

semilogy(b_error1,'rx')
hold on
semilogy(b_error2,'bo')
semilogy(b_error3,'m+')
semilogy(b_error4,'g*')
semilogy(b_error5,'ro')
xlim([0 400])
lb1 = 'Tp for odd degree';
lb2 = 'Tp for even degree';
lb3 = 'Tp for odd degree + non-unitary deflation';
lb4 = 'Tp for odd degree + unitary deflation';
lb5 = 'Dk';
legend({lb1,lb2,lb3,lb4,lb5},'box','off','color','none','FontSize',18,'Location','southwest')
