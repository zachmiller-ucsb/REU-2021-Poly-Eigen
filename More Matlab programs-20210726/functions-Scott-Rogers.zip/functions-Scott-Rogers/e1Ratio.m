function [Y,E,D] = e1Ratio(L,P)
%Finds the Condition number (kl) of linearization with coefficients L = {-L_0,
%L_1} for each eigenvalue
%Finds the Condition number (kp) of matrix polynomial with coefficients P =
%{A_0,A_1,...,A_k} for the same eigenvalue.
%Computes r = kl/kp
    digits(40);
    L = {vpa(L{1}), vpa(L{2})};
    k = length(P)-1; %degree of polynomial
    n = size(P{1},1); %size of coefficients
    E = 1:(n*k); %indices for eigenvalues
    Y = zeros(1,n*k);
    Y = sym(Y,'f');
   % N = zeros(1,n*k);
   % N = sym(N,'f');
     
   
    [C1,iL1] = Cp(L); %Creates symbolic Cp for linearization with coefficients L
    C1 = vpa(C1);
    [V1,D1] = eig(C1); %Creates symbolic Vi and Di for Ci, Vi contains right eigvectors, (Wi left),
    V1 = vpa(V1);
    D = vpa(diag(D1));
    [~,I] = sort(abs(D));
    D = D(I);
    V1 = V1(:,I');
    %disp('C1,V1,D1 created.');
   
    V2 = V1(k*n/2+1-n:k*n/2,:);
    
    [W1,otherD] = eig(C1.'); %Di contains eigvals on diag
    otherD = vpa(diag(otherD));
    I = zeros(1,length(D));
    
    for i=1:length(D)
        index = find(eval(otherD)==eval(D(i)),1);
        I(i) = index;
    end
        
    W1 = vpa(W1);
    W1 = W1(:,I');
    W1 = ctranspose(iL1)*conj(W1);
    
    %disp('W1,D1 created.');

    W2 = W1(k*n/2+1-n:k*n/2,:);
    
   
    for i=1:length(D) %for eigenvalues of linearization
        
        e = D(i); %eigenvalue
%         disp('eigenvalue:');
%         disp(vpa(e));
        
        x1 = V1(:, i); %corresponding right eigvec
        y1 = W1(:, i); %""" left eigvec
        
        %dL = deltaP(L);
        %if eval(e) ~= 0 && eval(abs(ctranspose(y1)*dL(e)*x1)) ~= 0
            
        %tic

        kl = cnum(L,e,x1,y1); %add semicolon
        %nl = berror(L,x1,e);
        %toc

        x2 = V2(:, i); %corresponding right eigvec
        y2 = W2(:, i); %""" left eigvec

        %tic
        kp = cnum(P,e,x2,y2);
        %np = berror(P,x2,e);
        %toc

%         disp('Quotient:');
%         disp(vpa(kl/kp));
        r1 = vpa(kl/kp,40);
        %r2 = vpa(np/nl,40);

        Y(i) = r1;
        %N(i) = r2;
        c = double(i/(n*k) * 100);
        disp([num2str(c),'% complete.']);

        %end
    end
end
