function L = E2(P)
k = length(P)-1;
% if mod(k,2) == 1
%     return;
% end
n = size(P{1},1);
M1 = [zeros(n,n) P{k+1} zeros(n,n*(k/2-1));P{k+1} P{k} zeros(n,n*(k/2-1))];
for j = 2:k/2
    M1 = [M1;zeros(n,n*j) P{k-2*j+2} zeros(n,n*(k/2-j))];
end
%disp(M1);
M0 = [-P{k+1} zeros(n,n*k/2)];
for j = 1:k/2
    M0 = [M0;zeros(n,n*j) P{k-2*j+1} zeros(n,n*(k/2-j))];
end
%disp('');
%disp(M0);

s = (k-2)/2;
J1 = [zeros(s,1) eye(s)];
J0 = [-eye(s) zeros(s,1)];
K1 = kron(J1,eye(n));
K0 = kron(J0,eye(n));
L1 = [M1 [zeros(n,s*n); K1'];zeros(s*n,n) K1 zeros(s*n)];
L0 = [M0 [zeros(n,s*n); K0'];zeros(s*n,n) K0 zeros(s*n)];
L = {L0,L1};
% disp(L1);
% disp(L0);
end
