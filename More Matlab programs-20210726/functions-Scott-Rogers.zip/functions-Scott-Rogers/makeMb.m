function [M] = makeMb(P)
k = length(P)-1;
n = size(P{1},1);
M = eye(n*(k/2+1));
M = [M zeros(n*(k/2+1),n*(k/2-1))];
for j = 1:k/2-1
    row = zeros(n,n*j);
    for l = k-2*j+1:-1:1
        row = [row -P{l}];
    end
    row = [row zeros(n,n*(j-1))];
    M = [M;row];
end

end

