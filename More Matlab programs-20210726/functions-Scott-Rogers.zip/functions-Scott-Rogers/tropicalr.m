%%% Consideramos el polinomio en relative-pose-5pt, el cual tiene leading
%%% coefficient singular, y calculamos las normas de los coeficientes, y
%%% las tropical roots. 

function [Q,gamma, normasr]=tropicalr(r,P,n,k)

digits(40);
                  tic
       
            %P = genP(k,n,10);
            %k = 3;
            %n = 10;
            %P = nlevp('relative_pose_5pt');
            
            normas=zeros(k+1,1);
           
            for i = 0:k
                P{i+1} = vpa(P{i+1});
                normas(i+1)=norm(P{i+1});
            end
          S=max(normas);
         
          
         
    
            normasr=cell(1,k+1);
            Q=cell(1,k+1);
            if r==0
                for i=1:k+1
                    Q{i}=P{i};
                    normasr{i}=vpa(norm(Q{i}));  
                    gamma=1;
                end
                
            elseif  r==1
                for i=1:k+1
                    Q{i}=P{i}/S;
                    normasr{i}=vpa(norm(Q{i}));
                    gamma=1;
                end
                
            end
            