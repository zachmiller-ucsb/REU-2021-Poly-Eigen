function L = D1(P)
k = length(P)-1;
% if mod(k,2) == 1
%     return;
% end
n = size(P{1},1);

L1 = [P{k+1} zeros(n,n*(k-1))];
for i = 2:k
    L1row = [zeros(n)];
    for j = k-i:-1:0
        L1row = [L1row -P{j+1}];
    end
    L1row = [L1row zeros(n,n*(i-2))];
    L1 = [L1;L1row];
end
L0 = [];
for i = 1:k
    L0row = [];
    for j = k-i:-1:0
        L0row = [L0row P{j+1}];
    end
    L0row = [L0row zeros(n,n*(i-1))];
    L0 = [L0;L0row];
end
L = {L0,L1};

end

