function [L1,L0] = C(k)
%Creates C1 companion pencil for P of degree k
    L1 = pemOp(eye(k),-k);
    L0 = eye(k);
    for i = 0:k-1
        L0 = pemOp(L0,i);
    end
    
    

