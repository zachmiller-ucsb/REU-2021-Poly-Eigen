function eta = berror(P,x,lambda)
%Returns the backward error for Matrix polynomial P for eigenpair
%(lambda,x)
    k = length(P)-1;
    for i = 1:k+1
        P{i} = double(P{i});
    end
    eta1 = 0;
    eta2 = 0;
    for i=0:k
        eta1 = eta1 + P{i+1}*(lambda^i);
        eta2 = eta2 + abs(lambda^i) * norm(P{i+1});
    end
    eta1 = norm(eta1*x);
    eta2 = eta2 * norm(x);
    eta = eta1/eta2;

