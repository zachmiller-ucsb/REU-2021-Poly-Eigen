%%% Consideramos el polinomio en relative-pose-5pt, el cual tiene leading
%%% coefficient singular, y calculamos las normas de los coeficientes, y
%%% las tropical roots. 

function [Q, gamma, normasr]=tropical(r)

digits(40);
                  tic
       
            %P = genP(k,n,10);
            k = 3;
            n = 10;
            P = nlevp('relative_pose_5pt');
            
            normas=zeros(4,1);
           
            for i = 0:k
                P{i+1} = vpa(P{i+1});
                normas(i+1)=norm(P{i+1});
            end
          S=max(normas);
          %log(normas)
         % x=[0;1;2;3]; y=log(normas);
         % plot(0:3,log( normas), '*')
          %puntos=convhull(x,y);  %calculamos el convex hull
          
         %hold on
         %plot(x(puntos), y(puntos),'-r'), hold off
         
          
          % In this case, the upper boundary of the newton polygon contains all pairs of the form
          % (i, log(norma(i))). Thus, the tropical polynomial (norma(A0),
          % norma(A1)la, norma(A2) la^2, norma(A3)la^3) has three tropical
          % roots of multiplicity 1 that we give next.
          m=zeros(1,3);
          troproots=zeros(1,3);
          for i=1:3
              troproots(i)=normas(i)/normas(i+1);
          end
          
         % Next we compute the scaling parameters.
         
         ka=zeros(1,3);
          beta=zeros(1,3);
          
            for i=1:3
                ka(i)=i-1;
                beta(i)=(normas(i)*troproots(i)^ka(i))^(-1);
            end
            normas;  ka;  troproots;  beta;
            normasr=cell(1,4);
            Q=cell(1,4);
            if r==0
                for i=1:4
                    Q{i}=P{i};
                    normasr{i}=vpa(norm(Q{i}));
                    %beta=1;
                    gamma=1;
                end
                
            elseif  r==1
                for i=1:4
                    Q{i}=P{i}/S;
                    normasr{i}=vpa(norm(Q{i}));
                    %beta=1/S;
                    gamma=1;
                end
                
            elseif r==2     
          for i=1:4
                Q{i}=beta(1)*troproots(1)^(i-1)*P{i};
                normasr{i}=vpa(norm(Q{i}));
                %beta=beta(1);
                gamma=troproots(1);
          end
            
            elseif r==3
       
            for i=1:4
                Q{i}=beta(2)*troproots(2)^(i-1)*P{i};
                normasr{i}=vpa(norm(Q{i}));
                %beta=beta(2);
                gamma=troproots(2);
            end
            
            elseif r==4   
            
            for i=1:4
                Q{i}=beta(3)*troproots(3)^(i-1)*P{i};
                normasr{i}=vpa(norm(Q{i}));
                %beta=beta(3);
                gamma=troproots(3);
            end
         end   
            for i=1:4
                Q{i}=double(Q{i});
            end