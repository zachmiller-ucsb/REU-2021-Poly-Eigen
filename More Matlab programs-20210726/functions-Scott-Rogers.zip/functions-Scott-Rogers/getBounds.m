function [b1,b2] = getBounds(P,s,e)
%P are the coefficients P={A_0,A_1,...,A_k}
%e is the eigenvalue
%s is a string which specifies which type of linearization you are
%comparing to. e.g. s = 'Dp' is for linearizations in the Dp family.
    digits(40);
    k = length(P) - 1;

    if strcmp(s,'DLP')
        
        X = cell(1,k+1);
        for i = 1:k+1;
            X{i} = norm(P{i});
        end
        
        maxNorm = max([X{:}]);
        minNorm = min([X{1},X{length(X)}]);
        
        ro = vpa(maxNorm/minNorm);
        b1 = 1/(ro);
        %b2 = k^(7/2)*ro^2;
        b2 = 2*k^2*ro;
    elseif strcmp(s,'Dp')           
        
        X = cell(1,k+1);
        for i = 1:k+1;
            X{i} = norm(P{i});
        end
        
        maxNorm = max([X{:}]);
        minNorm = min([X{1},X{length(X)}]);
        
        ro1 = vpa(max(maxNorm,1)^3/minNorm);
        ro2 = vpa(min(minNorm,1)/maxNorm);
        b1 = ro2 * 1/k;  
        
        if mod(k,2) && (abs(vpa(e)) >= 1)
            b2 = 4*k^4*ro1;
              
        elseif abs(vpa(e)) <= 1
            b2 = 5/2*k^4*ro1;  
        else 
            b2 = -1; %-1 means the condition number fulfills none of the requirements.
        end
    elseif strcmp(s,'T') %as of now, only supports k = odd
        X = cell(1,k+1);
        for i = 1:k+1;
            X{i} = norm(P{i});
        end
        
        maxNorm = max([X{:}]);
        minNorm = min([X{1},X{k+1}]);
        
        ro1 = vpa(max([maxNorm,1])^3/minNorm);
        ro2 = vpa(min([minNorm,1])/maxNorm);
        
        b1 = ro2/k;
        b2 = 2*k^4*ro1;
    elseif strcmp(s,'Ts') %as of now, only supports k = odd
        X = cell(1,k+1);
        for i = 1:k+1;
            X{i} = norm(P{i});
        end
        
        maxNorm = max([X{:}]);
        minNorm = min([X{1},X{length(X)}]);
        
        ro1 = vpa(max([maxNorm,1])^3/minNorm);
        ro2 = vpa(min([minNorm,1])/maxNorm);
        ro1p = vpa(max([maxNorm,1])^2/minNorm);
        
        b1 = ro2/k;
        b2 = 2*k^4*ro1;
    end


