function k = cnum(P,lambda, x, y)
    %returns the condition number for matrix polynomial with coefficients
    %P={A_0, A_1, ..., A_k} evaluated at lambda
    
    %Test P(lambda)x = 0, y*P(lambda)=0
    digits(40);
    
        
%     disp('y:');
%     disp(vpa(y)); %comment
%     disp('x:');
%     disp(vpa(x));
    
%     f = getPoly(P);
%     disp('left eigenvector check:');
%     disp(ctranspose(y) * f(lambda));
%     disp('right eigenvector check:');
%     disp(f(lambda)*x);

    k = length(P)-1;
    syms d;
    kappa1 = symfun(0, d); 
    kappa2 = symfun(deltaP(P), d);
    for i=0:k
        kappa1 = kappa1 + abs(d)^i * norm(P{i+1});
    end
    kappa1 = kappa1 * norm(y) * norm(x);
%     a = ctranspose(y) * kappa2;
%     b = kappa2*x;
%     disp('y* L1')
%     disp(a(lambda));
%     disp('L1 x');
%     disp(b(lambda));
%     disp('(y* L1) x')
%     disp(a(lambda)*x);

    kappa2 =abs(d)*abs(ctranspose(y)*kappa2*x);
%     disp('Denominator of L:');
%     disp(vpa(kappa2(lambda)));
%disp(kappa2(lambda));
    
    k = kappa1/kappa2;
    k = k(lambda);