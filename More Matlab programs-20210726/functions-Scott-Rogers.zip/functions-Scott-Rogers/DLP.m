function [L1,L0] = DLP(k,i)
%DLP Summary of this function goes here
%   Detailed explanation goes here
 
    if i == 1
		
		L1 = zeros(k);
		L1(1,1) = k+2;
        for j1 = 2:k+1
            for j2 = 2:(k-j1+2)
				L1(j2,j1) = -(k-j1-j2+4);
            end
        end
		L0 = zeros(k);
        for j1 = 1:k
            for j2 = 1:(k-j1+1)
				L0(j2,j1) = -(k-j1-j2+3);
            end
        end	
        
    elseif i == k
        
        L1 = zeros(k);
        for j1 = 1:k
            for j2 = 0:j1-1
				L1(k-j2,j1) = k-j1+j2+3;
            end
        end
        
        L0 = zeros(k);
        L0(k,k) = -2;
        for j1 = 1:k-1
            for j2 = 1:j1
				L0(k-j2,j1) = (k+2) - (j1-1) + (j2-1);
            end
        end        
    end