function L = Dk(P)
k = length(P)-1;
% if mod(k,2) == 1
%     return;
% end
n = size(P{1},1);

L1 = [];
for i = 1:k
    L1row = [zeros(n,n*(k-i))];
    for j = k:-1:k-i+1
        L1row = [L1row P{j+1}];
    end
    L1 = [L1;L1row];
end
L0 = [];
for i = 1:k-1
    L0row = [zeros(n,n*(k-i-1))];
    for j = k:-1:k-i+1
        L0row = [L0row -P{j+1}];
    end
    L0row = [L0row zeros(n)];
    L0 = [L0;L0row];
end
L0 = [L0;zeros(n,n*(k-1)) P{1}];
L = {L0,L1};

end

