function [Np,r] = etatRatio(Lp, P, Lq, Q, gamma)
%ETATRATIO returns list of np/nl in order for sorted eigenvalues (sorted by
%ascending magnitude) when P is not scaled.
    k = length(P) - 1;
    n = size(P{1},1);

    Np = zeros(1,n*k);
%    Nq= zeros(1,n*k);
    E= zeros(1, n*k);
 
    
    [V1,D] = polyeig(double(Lp{1}),double(Lp{2})); %V1: eigenvectors; D: eigenvalues; sin escalar.
    [~, I] = sort(abs(D));
    D = D(I);
    V1 = V1(:,I');
%     [V2,D2]=polyeig(Lq{1},Lq{2});
%     [~,J]=sort(abs(D2));
%     D2=D2(J);
%     V2=V2(:,J');
    %D2=gamma*D2;
    %[~,R]=sort(abs(D2));
    %D2=D2(R);
    %V2=V2(:,R');
    
    R = zeros(n*k,1);
    for i=1:length(D)
        e = D(i);
        x1 = V1(:,i);
%         x3=V2(:,i);
%         e4=D2(i);
%        e3=gamma*e4;
        nlp = berror(Lp,x1,e);   %backward error of Lp
 %       nlq = berror(Lq,x3,e4);  %backward error of Lq
        
        if abs(e) > 1
            x2 = V1(1: n,i);
%            x4= V2(1:n,i);%recovery of eigenvector for P
        else
            x2 = V1(n*(k-1)+1: n*(k),i);
%            x4= V2(n*(k-1)+1:n*k, i);
        end
        R(i) = norm(x1)/norm(x2);
        
        np1 = berror(P,x2,e);
%        np2= berror(P,x4,e3);
        %backward error of P
        
        Np(i) = np1/nlp;
%        Nq(i)=np2/nlq;
        E(i)=norm(x1)/norm(x2); % quotient of norm of eigenvector of L and norm of eigenvector of P
       
    end
    r = max(R);
 
   %[n, I]=max(Np);
   e=max(E);
   
  