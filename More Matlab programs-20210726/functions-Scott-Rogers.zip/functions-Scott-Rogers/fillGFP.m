function [nL1,nL0] = fillGFP(L1,L0,P)
%takes GFP skeleton and list of coefficients P = A_0 A_1 ... A_k
% and replaces A_i with corresponding matrices.
    k = length(P)-1;
    n = size(P{1});

    nL1 = zeros(n*k);
    %nL1 = sym(nL1,'f');
    for i = 0:(k-1) %Takes L1(i,j), converts it to a matrix, places it in nL1
        for j = 0:(k-1)
            if L1(i+1,j+1) == 1
                nL1(i*n+1:(i+1)*n, j*n+1:(j+1)*n) = eye(n);
            elseif L1(i+1,j+1) > 0 
                if L1(i+1,j+1) < 1
                    w = (1/L1(i+1,j+1) - 2);
                    nL1(i*n+1:(i+1)*n, j*n+1:(j+1)*n) = P{w+1}\eye(n);
                else
                    w = L1(i+1,j+1) - 2;
                    nL1(i*n+1:(i+1)*n, j*n+1:(j+1)*n) = P{w+1};
                end
            elseif L1(i+1,j+1) < 0 
                if L1(i+1,j+1) > -1
                    w = -1/L1(i+1,j+1) - 2;
                    nL1(i*n+1:(i+1)*n, j*n+1:(j+1)*n) = P{w+1}\eye(n) *-1;
                else
                    w = -L1(i+1,j+1) - 2;
                    nL1(i*n+1:(i+1)*n, j*n+1:(j+1)*n) = P{w+1}*-1;
                end
            end
        end
    end

    nL0 = zeros(n*k);
    %nL0 = sym(nL0,'f');
    for i = 0:(k-1) %Takes L0(i,j), converts it to a matrix, places it in nL0
        for j = 0:(k-1)
            if L0(i+1,j+1) == 1
                nL0(i*n+1:(i+1)*n, j*n+1:(j+1)*n) = eye(n);
            elseif L0(i+1,j+1) > 0 
                if L0(i+1,j+1) < 1
                    w = (1/L0(i+1,j+1) - 2);
                    nL0(i*n+1:(i+1)*n, j*n+1:(j+1)*n) = P{w+1}\eye(n);
                else
                    w = L0(i+1,j+1) - 2;
                    nL0(i*n+1:(i+1)*n, j*n+1:(j+1)*n) = P{w+1};
                end
            elseif L0(i+1,j+1) < 0 
                if L0(i+1,j+1) > -1
                    w = -1/L0(i+1,j+1) - 2;
                    nL0(i*n+1:(i+1)*n, j*n+1:(j+1)*n) = P{w+1}\eye(n) *-1;
                else
                    w = -L0(i+1,j+1) - 2;
                    nL0(i*n+1:(i+1)*n, j*n+1:(j+1)*n) = P{w+1}*-1;
                end
            end
        end
    end
    
