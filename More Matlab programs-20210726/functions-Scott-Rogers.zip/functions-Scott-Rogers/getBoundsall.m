function [ro, ro1, rop,bTc,bDc,bCc,X] = getBoundsall(P,s)
%P are the coefficients P={A_0,A_1,...,A_k}
%e is the eigenvalue
%s is a string which specifies which type of linearization you are
%comparing to. e.g. s = 'Dp' is for linearizations in the Dp family.
%this program computes the upper bound of condition numbers 
% of all four linearizations D1, Dk, C1 and Tp.

    %digits(40);
    k = length(P) - 1;
    n = size(P{1},1);
    
    
    
    if strcmp(s,'T') %as of now, only supports k = odd. Computes bounds for unscaled case. 
        X = cell(1,k+1);
        for i = 1:k+1
            P{i} = vpa(P{i});
            X{i} = norm(P{i});
        end

  
        
        
        
        maxNorm = max([X{:}]);
        minNorm = min([X{1},X{k+1}]);
        
        ro=real(maxNorm/minNorm);
        %ro=vpa(ro);
        ro1 = real(max([maxNorm,1])^3/minNorm); %%Gets rid of insignificant imaginary parts
        %ro1 = vpa(ro1);
        %ro2 = real(min([minNorm,1])/maxNorm); %%Gets rid of insignificant imaginary parts
        %ro2 = vpa(ro2);
        rop = real(max([maxNorm,1])^2/minNorm);%%Gets rid of insignificant imaginary parts
        %rop = vpa(rop);
        
        %b1 = ro2;
        bDc=k^2*ro; %upper bound for condition number of D
        %bDb=k^(3/2)*ro; % partial upper bound for backward error of D
        bCc=2*sqrt(2)*k^(3)*rop; %upper bound for condition number of C1
        %bCb=k^(5/2)*rop; %partial upper bound for backward error of C1
        bTc = 2*k^3*ro1; % upper bound for condition number of TP
        %b1p = (k*n)^(-1/2) * ro2;
        %bTb = 4*k^(3/2)*rop; % partial upper bound for backward error of Tp
        
    elseif strcmp(s,'Ts') %as of now, only supports k = odd. Computes bounds for scaled case
        X = cell(1,k+1);
        for i = 1:k+1;
            P{i} = vpa(P{i});
            X{i} = norm(P{i});
        end
        
        
        maxNorm = max([X{:}]);
        minNorm = min([X{1},X{length(X)}]);
        
        ro=real(maxNorm/minNorm);
        ro1 = real(1/minNorm);%%Gets rid of insignificant imaginary parts
        %ro1 = vpa(ro1); 
        %ro2 = real(min([minNorm,1])/maxNorm);%%Gets rid of insignificant imaginary parts
        %ro2 = vpa(ro2);
        rop = real(1/minNorm);%%Gets rid of insignificant imaginary parts
        %rop = vpa(rop);
        
       bDc=k^2*ro; %upper bound for condition number of D
       % bDb=k^(3/2)*ro; % partial upper bound for backward error of D
        bCc=2*sqrt(2)*k^(3)*rop; %upper bound for condition number of C1
       % bCb=k^(5/2)*rop; %partial upper bound for backward error of C1
        bTc = 2*k^3*ro1; % upper bound for condition number of TP
        %b1p = (k*n)^(-1/2) * ro2;
       % bTb = 4*k^{3/2}*rop; % partial upper bound for backward error of Tp
    end


