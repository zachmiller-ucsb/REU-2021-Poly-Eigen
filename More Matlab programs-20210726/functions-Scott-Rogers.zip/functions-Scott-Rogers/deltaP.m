function dP = deltaP(P) %P= {A_0, A_1, ..., A_k} is 1x(k+1) cell array.
    %Takes the symbolic derivative of Matrix Polynomial and returns it.
    k = length(P)-1;
    syms d;
    f = symfun(1,d)*P{1};
    for i=1:k
        f = f + symfun(d^i,d)*P{i+1};
    end
    dP = diff(f);
        