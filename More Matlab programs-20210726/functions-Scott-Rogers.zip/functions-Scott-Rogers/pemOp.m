function A = pemOp(A,i) %takes matrix A and index i and performs row operations equivalent to M_i * A
    k = size(A,2);
    if i == 0 % i = 0
        A(k,:) = A(k,:)*(-2);
        %disp(i)
        %disp(A)
    elseif i == k %i = k
        A(1,:) = A(1,:)*(1/(-i-2));
        %disp(i)
        %disp(A)
    elseif i == (-1*k) %i = -k
        A(1,:) = A(1,:)*(-1*i+2);
        %disp(i)
        %disp(A)
    elseif i > 0
        B = A(k-i,:)*(-(i+2));
        B = B + A(k-i+1,:);
        A(k-i+1,:) = A(k-i,:);
        A(k-i,:) = B;
        %disp(i)
        %disp(A)
    else
        B = A(k+i+1,:)*(-1*i+2);
        B = B + A(k+i,:);
        A(k+i,:) = A(k+i+1,:);
        A(k+i+1,:) = B;
        %disp(i)
        %disp(A)        
    end
    
    