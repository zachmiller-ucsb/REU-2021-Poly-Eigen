function P = genPhighbounds(k,n,r)
    P = cell(1,k+1);
    P{1} = sym(-r + (2*r)*rand(n), 'f');
    for i = 2:k+1 %enters random nxn matrices with entries [-10,10] for A_0 to A_{k-1}
        P{i} = P{1};
    end
    