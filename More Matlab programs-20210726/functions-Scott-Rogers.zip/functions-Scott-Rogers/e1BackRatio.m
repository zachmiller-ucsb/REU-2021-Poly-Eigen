function [N,r] = e1BackRatio(Lp, P)
    k = length(P) - 1;
    n = size(P{1},1);
    N = zeros(1,n*k);
    [V1,D] = polyeig(double(Lp{1}),-double(Lp{2}));
    [~, I] = sort(abs(D));
    D = D(I);
    V1 = V1(:,I');
    R = zeros(n*k,1);
    for i=1:n*k
        e = D(i);
        y = V1(:,i);
        
        nlp = berror(Lp,y,e);
        x = y(n*k/2+1:n*(k/2+1));
        np = berror(P,x,e);
        R(i) = norm(y)/norm(x);
        N(i) = np/nlp;
        
    end
    r = max(R);

end
