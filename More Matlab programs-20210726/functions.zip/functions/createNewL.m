function L = createNewL(nodes)
V = fliplr(vander(nodes));

U = ones(length(nodes));

    for cols = 1:length(nodes)
        for rows = 1:length(nodes)
            
            if rows == 1
                U(rows, cols) = 1;
            elseif cols < rows
                U(rows, cols) = 0;
            else
                for k = 1:rows-1
                    U(rows, cols) = U(rows, cols)*(nodes(cols)-nodes(k));
                end
            end
            
        end
    end
    
U = inv(U);
L = V'*U;
L = round(L);
end