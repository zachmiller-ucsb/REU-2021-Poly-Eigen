function [u,l] = bounds_simple(d,L)
    % Generates upper and lower bounds of the ratio of the condition number
    % for the eigenvalues of a matrix polynomial in two bases a and b, where L
    % is the change of basis matrix between these two bases, and d is the
    % degree of the matrix polynomial.
    c = cond(L, 'inf');
    u = c*sym((d+1));
    l = 1/u;
end

