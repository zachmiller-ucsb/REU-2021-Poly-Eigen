function [rmax,c] = minCircle(nodes)
% The following function takes in complex nodes as a row vector, then
% computes the radius and center of the circle that minimally encloses the
% nodes. 

n = [real(nodes') imag(nodes')];
c = [mean(n(:,1)) mean(n(:,2))];
c = c(1) + 1i*c(2);
rmax = 0;
for j = 1:length(nodes)
    r = norm(c - n(j,:));
    if r > rmax
        rmax = r;
    end  
end
end