function [u,l] = bound_norm(d, L)
    u = (d+1)*norm(L,"inf"); %L = cheb to mon matrix
    l = 1/((d+1)*norm(inv(L), "inf")); %inv(L) = mon to cheb matrix 
end