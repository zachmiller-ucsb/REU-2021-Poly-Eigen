function [u,l] = bounds_cond_2(d,Vt)
    u = (d+1)^3*sqrt(2/pi)*cond(Vt,2);
    l = 1/u;
end