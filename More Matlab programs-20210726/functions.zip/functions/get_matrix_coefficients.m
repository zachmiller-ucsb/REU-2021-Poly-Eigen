% gets a symbolic, square matrix polynomial and returns the symbolic matrix
% coefficients

% returns matrix coefficients in monomial basis ordered from P*1 to P*x^d
function matrices = get_matrix_coefficients(d,M)
    n = size(M,1);
    matrices = sym(zeros(n,n,d+1));
    for i = 0:d
        matrices(:,:,i+1) = subs(diff(M,i)/factorial(i), 0);
    end
end