% outputs column vector of eigenvalues in a real interval

function e = get_e(d,a,b)
    e = sym(a + abs(b-a)*rand(d,1));
end