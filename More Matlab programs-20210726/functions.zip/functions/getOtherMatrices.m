function vals = getOtherMatrices(Q,matrices)
% This function takes a set of matrix coefficients for a polynomial written in
% basis A, and outputs a new set of matrix coefficients for the polynomial
% written in basis B, by applying the basis change matrix Q over the implied
% variable parts of each monomial in the matrix polynomial.
%
% It is implied that the polynomial P has degree n - 1, that Q has dimension
% nxn, and that therefore there are n matrix coefficients to rewrite using Q.
% Further, it is assumed matrices is a 3d array of size mxmxn, with the
% polynomial coefficients indexed by (:,:,k) with 1 <= k <= n, and m being
% the size the (square) matrix polynomial P.

    vals = sym(zeros(size(matrices)));
    numMatrices = size(matrices,3);
    Q = sym(Q);
    
    for i = 1:numMatrices
        for j = 1:numMatrices
            %linear combination of matrices using basis transformation
            vals(:,:,i) = vals(:,:,i) + Q(i,j) * matrices(:,:,j); 
        end
    end
end

