function L = montocheb(N)
    %Change of basis matrix from monomial to chebyshev
C=chebpoly(N); 
A=zeros(N+1); 
for k = 1:N+1
    A(k:N+1,k)=C{N+2-k}; 
end
L=inv(fliplr(flipud(A))); 




