function basis = LagrangeBasis(nodes, x)
% This function finds the Lagrange basis elements evaluated at values x
% for the number of nodes provided. x is a column vector, and the nodes are
% input as a row vector.
    d = length(nodes);
    basis = zeros(length(x),d);
    for i = 1:d
        a = nodes(i);
        nodes_alt = nodes;
        nodes_alt(i) = [];
        basis(:,i) = prod(x - nodes_alt,2)/prod(a - nodes_alt,2);
    end
end