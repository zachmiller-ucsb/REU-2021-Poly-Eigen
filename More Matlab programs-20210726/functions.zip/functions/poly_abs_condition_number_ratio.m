function K = poly_abs_condition_number_ratio(a, b, A, B)
% This function takes the ratio of the absolute condition numbers for
% matrix polynomials in a basis A and the condition number of matrix
% polynomials in basis B. It computes this value exactly. a represents the
% elements of the basis, evaluated at the eigenvalue(s) considered, in a 
% column vector that is of length d+1, where d is the degree of the 
% polynomial. A represents the matrix coefficients in basis a, and the 
% variable A is of size nxnx(d+1), where each matrix coefficient is square. 
% A(:,:,1) corresponds to the matrix coefficient of a(1), and A(:,:,d+1) 
% corresponds to the matrix coefficient of a(d+1). B is the matrix
% coefficients of the basis b, with b being the basis elements evaluated
% at the eigenvalue(s), ordered in the same way. This is the ratio of 
% K_{RA,A} to K_{RA,B}.


s = size(A);
d = s(3);
maxA = 0;
maxB = 0;
for i = 1:d
    maxA = max(maxA, norm(A(:,:,i),2));
    maxB = max(maxB, norm(B(:,:,i),2));
end

a_sum = sum(abs(a),2);
b_sum = sum(abs(b),2);

K = (maxA / maxB)*(a_sum ./ b_sum);

end
