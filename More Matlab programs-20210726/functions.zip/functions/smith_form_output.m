% This multiplies symbolic unimodular matrices in the smith form 
% with a symbolic diagonal matrix whose eigenvalues are
% the input e such that these eigenvalues are simple. NOTE that
% the number of eigenvalues determines the degree, d, of the 
% matrix polynomial. The output is one symbolic matrix polynomial.
% Note that e must be an array of symbolic eigenvalues

% The matrices low_U and up_U are random lower and upper triangular
% matrices that are trivially unimodular. The non-zero entries that are not
% on the diagonal are random integers within the interval [a,b] and the
% entries on the diagonal are either 1 or -1.

function M = smith_form_output(n,e,a,b)

    % generates the smith diagonal matrix with simple eigenvalues
    D = sym(eye(n));
    poly = 1;
    syms x;
    for i = 1:length(e)
        poly = poly * (x - e(i));
    end
    D(n,n) = poly;
    
    rand_matrix = sym(a + abs(b-a)*rand(n,n));
    rand_matrix2 = sym(a + abs(b-a)*rand(n,n));
    
    % The code below computes upper and lower triangular matrices
    %diags = [1,-1];
    %low_U = tril(rand_matrix); % These matrices are almost guaranteed to
    %up_U = triu(rand_matrix);  % be invertible.
    %for i = 1:n % replaces entries of the matrices with 1 or -1
    %    low_U(i,i) = diags(randi(2));
    %    up_U(i,i) = diags(randi(2));
    %end
    %low_U = sym(low_U);
    %up_U = sym(up_U);
    
    M = rand_matrix*D*rand_matrix2;
    
end