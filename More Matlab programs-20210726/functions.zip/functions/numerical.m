% Numerical Experiments
% This script allows you to utilize different functions in order to find
% the quotient of the eigenvalue condition number for matrix polynomials in
% two different bases. It is designed to be able to use different methods
% to calculate different parts, and sometimes has multiple ways of doing
% things with one way commented out in order to make it as user friendly as
% possible. The script is organized in the following layout:
% -Setup of variables such as the interval, size of the matrix coefficient
% matrices, and number of interations, as well as configuration of arrays
% -For loop that does the following:
%   -Gets monomial coefficient matrices and eigenvalues, either
%   symbolically through linearization (where it then saves the file for
%   later use) OR by using the Smith form
%   -Finds the nodes by definition of the user (currently Chebyshev type 1
%   and equispaced are listed for convenience)
%   -Finds the coefficient matrices in another polynomial basis by the user
%   providing the change of basis matrix from the monomials to basis x on
%   the line "M = ...". Currently Vandermonde is listed for the Lagrange
%   polynomials
%   -Provide the function which takes the input of the nodes and the
%   eigenvalues to find the basis elements evaluated at the eigenvalue at
%   the line "xi=...". Currently for Lagrange Basis
%   -Can change function that finds bounds to produce different upper and
%   lower bounds depending on which is desired to see. The function should
%   produce the upper and lower bound for the input
% Then, the bounds and the quotients of the condition numbers are plotted
% on semilogy plots, with labeled axes and legend. Change the title when
% the basis/nodes are changed. Note that "good" eigenvalues means
% eigenvalues within the minimum ball that enclosed the nodes on the
% complex plane, and bad means outside of that circle. 
%
% To work, the following script needs access to the following functions: a
% bounds function (currently bounds_simple.m), eigenRange.m, a
% function that generates the matrix polynomial and eigenvalues (currently
% findPwithEvals.m, which needs genP.m and Cp.m), getOtherMatrices.m, a
% function that evaluates a number at elements of the basis (currently
% LagrangeBasis.m), minCircle.m, and poly_abs_condition_number_ratio.m.

clear; clc; close all;
% enter desired interval (used for computing interval for matrix coeffs)
a = -1;
b = 1;

% size of matrices (nxn)
n = 3;

% number of iterations
maxd = 8;

% define accuracy
digits(40);

% Configure arrays for plotting
gk = cell(maxd,1);
bk = cell(maxd,1);
u = zeros(maxd,1);
l = zeros(maxd,1);
gex = cell(maxd,1);
bex = cell(maxd,1);
x = 1:maxd;

for d = x
    % Two ways to get eigenvalues and monomial coefficients 
    
    % Define monomial coefficient matrices as cell, find Eigenvalues using
    % linearization
    [coeff_mon,e] = findPwithEvals(d,n,a,b);
    % Save eigenvalues and matrix coefficients
    filename = sprintf('poly%g.mat',d);
    save(filename,'coeff_mon', 'e', 'a', 'b');
    
    % Using Smith Form: TBD
    
    
    % Find Nodes
    %nodes = linspace(a,b,d+1); % equispaced
    nodes = sym(zeros(1,d+1)); % Chebyshev nodes first kind
    for j = 1:d+1
        nodes(j) = cos((2*j-1)*pi/(2*(d+1)));
    end
    
    % Find radius/center of Minimal Circle enclosing by nodes
    [r,c] = minCircle(nodes);
    
    % Determine with eigenvalues are within circle
    [good_e, bad_e, e, last_good_e] = eigenRange(e,r,c);
    temp_age = d*ones(size(good_e));
    temp_abe = d*ones(size(bad_e));
    gex{d} = temp_age;
    bex{d} = temp_abe;
    
    % Find Coefficients in Another Basis:
    M = sym(fliplr(vander(nodes))); % coefficient change of basis
    % convert coeff_mon from cell to array here
    coeff_mon_a = reshape(cell2sym(coeff_mon),n,n,d+1);
    coeff_x = sym(getOtherMatrices(M, coeff_mon_a));

    
    % Compute sum of monomial basis elements evaluated at eigenvalue
    monomial_basis = poly2sym(ones(d+1,1));
    mi = subs(monomial_basis, abs(e));

    % Compute other basis elements evaluated at eigenvalue 
    xi = sym(LagrangeBasis(nodes, e));

    
    % Compute ratio of condition number
    tempK = poly_abs_condition_number_ratio(xi,mi,coeff_x,coeff_mon_a);
    gk{d} = tempK(1:last_good_e);
    bk{d} = tempK(last_good_e+1:end);
    
    
    % Compute lower and upper bounds
    [u(d),l(d)] = bounds_simple(d,M);

end



semilogy(cell2sym(gex),real(cell2sym(gk)),'bo')
hold on
semilogy(cell2sym(bex),real(cell2sym(bk)),'ro')
semilogy(x,u,'m-')
semilogy(x,l,'m-')
legend('Good Condition Number','Bad Condition Number', 'Upper Bound',...
    'Lower Bound','Location', 'northwest')
xlabel('d')
ylabel('k')
title('Condition # Ratio (Lagrange/Monomial), Chebyshev Nodes') 
grid on
