% Interval [a,b] to start, and nxn matrix coefficients
tic
clear; clc; close all;
% endpoints of interval a and b
a = -1;
b = 1;

% size of matrices (nxn)
n = 3;

% number of iterations (d corresponds to the degree of the polynomial) 
maxd = 10;

% define accuracy
digits(40);

k = cell(maxd,1); 
u_cond_inf = zeros(maxd,1); %upper bound using inf cond #
l_cond_inf = zeros(maxd,1); %lower bound using inf cond #
u_cond_2 = zeros(maxd,1); %upper bound using Vt 
l_cond_2 = zeros(maxd,1); %lower bound using Vt 
u_norm = zeros(maxd,1); %upper bound using inf norm 
l_norm = zeros(maxd,1); %lower bound using inf norm 

%finds size of X and K
plot_length = maxd*(maxd+1)/2;

X = nan(plot_length, 1);
K = nan(plot_length, 1);

C = sym(cheb_to_mon(maxd)); % compute change of basis matrix of max size

for d = 1:maxd
    
    % uses summation formula for indexing
    start_index = (d-1)*d/2 + 1;
    end_index = d*(d+1)/2;
    X(start_index:end_index) = d*ones(d,1);
    
    subC = C(1:d+1,1:d+1); % gets the appropriate sub-matrix from C
  
    %generates matrix polynomial starting with random eigenvalues in input 
    e = get_e(d,-1,1);
    M = smith_form_output(n,e,a,b);
    coeff_mon_a = get_matrix_coefficients(d,M);
    coeff_cheb = getOtherMatrices(subC, coeff_mon_a);
    
    nodes = zeros(1,d+1); % Chebyshev nodes first kind
    for j = 1:d+1
        nodes(j) = cos((2*j-1)*pi/(2*(d+1)));
    end
    
    Vt = fliplr(vander(nodes)); %Transpose of vandermonde matrix

    % Compute sum of monomial basis elements evaluated at eigenvalue
    monomial_basis = poly2sym(ones(d+1,1));
    mi = subs(monomial_basis, abs(e));
    
    % Compute Lagrange basis elements evaluated at eigenvalue 
    ci = cheb_basis(d, e);

    % Compute ratio of condition number
    tempK = poly_abs_condition_number_ratio(ci,mi,coeff_cheb,coeff_mon_a);
    K(start_index:end_index) = tempK;
    
    % Compute lower and upper bounds
    [u_cond_inf(d),l_cond_inf(d)] = bounds_simple(d,subC);
    [u_cond_2(d), l_cond_2(d)] = bounds_cond_2(d,Vt);
    [u_norm(d), l_norm(d)] = bound_norm(d,subC);
    
    d % program is slow so this is a counter

end

x = 1:maxd;
scatter(X,K)
hold on
set(gca,"yscale","log");
semilogy(x,u_cond_inf,'b-')
semilogy(x,l_cond_inf,'b-')
semilogy(x,u_cond_2, 'g-')
semilogy(x,l_cond_2, 'g-')
semilogy(x,u_norm, 'm-',x,l_norm,'m-');

legend('Condition number',...
'cond inf','cond inf','cond 2','cond 2','norm','norm',...
    'Location', 'northwest')
xlabel('d')
ylabel('k')
title('Condition # Ratio (Chebyshev), Equispaced Nodes') 
%profile viewer
toc
hold off