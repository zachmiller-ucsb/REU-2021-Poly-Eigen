clear; clc; close all;
% endpoints of interval a and b
a = -1;
b = 1;

% size of matrices (nxn)
n = 3;

% number of iterations
maxd = 8;

% Chebyshev nodes & change of basis matrix (Vandermonde)
nodes = cell(maxd, 1);
Vt = cell(maxd,1);
for i = 1:maxd
    no = zeros(1,i+1);
    for j = 1:i+1
        no(j) = cos((2*j-1)*pi/(2*(i+1)));
    end
    nodes{i} = no;
    % nodes{i} = linspace(a,b,i+1); % equispaced
    Vt{i} = fliplr(vander(nodes{i}));
end

% Compute bounds and ratio
[k, u, l] = poly_condition_ratio_bounds(n,maxd,a,b,nodes,Vt,@LagrangeBasis);

% Prep for plotting
t = cell(maxd,1);
x = 1:maxd;
for i = x
    t{i} = i*ones(n*i,1);
end

% Plotting
semilogy(cell2sym(t),real(cell2sym(k)),'ro')
hold on
semilogy(x,real(u),'b-')
semilogy(x,real(l),'g-')
legend('Condition Number','Upper Bound','Lower Bound',...
    'Location', 'northwest')
xlabel('d')
ylabel('k')
title('Condition # Ratio (Lagrange/Monomial), Chebyshev Nodes') 
