% Tester!!!
% Let's try for interval [a,b] to start, and nxn matrix coefficients
tic
clear; clc; close all;
% endpoints of interval a and b
a = -10;
b = 10;

% size of matrices (nxn)
n = 3;

% number of iterations
maxd = 8;

% define accuracy
digits(40);

%profile on 

k = cell(maxd,1); 
u_cond_inf = zeros(maxd,1);
l_cond_inf = zeros(maxd,1);
u_cond_2 = zeros(maxd,1);
l_cond_2 = zeros(maxd,1);

good_X = {[]};
bad_X = {[]};
good_K = {[]};
bad_K = {[]};

K = [];

C = montocheb(maxd); % compute cheb matrix of max size

for d = 1:maxd
    
    subC = C(1:d+1,1:d+1);
  
    nodes = zeros(1,d+1); % Chebyshev nodes first kind
    for j = 1:d+1
        nodes(j) = cos((2*j-1)*pi/(2*(d+1)));
    end
    
    Vt = fliplr(vander(nodes));
    % convert coeff_mon from cell to array here
    coeff_mon_a = reshape(cell2sym(coeff_mon),n,n,d+1);
    coeff_cheb = getOtherMatrices(subC, coeff_mon_a);

    % Find Eigenvalues 
    % Choose one eigenvalue by creating linearization, in order to use eig
    [L, ~] = Cp(coeff_mon);
    e = eig(L);
    
    a = -1; %changing interval for eigenvalues
    b = 1;
    
    indices = find(e <= b & e >= a);
    good_e = e(indices);  % get only eigenvalues in [a,b]
    
    bad_e = e;             
    bad_e(indices) = [];  % get eigenvalues outside of [a,b]
    
    last_good_e = length(good_e);
    
    e = [good_e; bad_e];
    
    temp_arr = d*ones(size(good_e)); % this variable is used to simplify notation
    good_X = [good_X, mat2cell(temp_arr, length(temp_arr),1)];
    
    temp_arr = d*ones(size(bad_e));
    bad_X = [bad_X, mat2cell(temp_arr, length(temp_arr),1)];
    
    % Compute sum of monomial basis elements evaluated at eigenvalue
    monomial_basis = poly2sym(ones(d+1,1));
    mi = subs(monomial_basis, abs(e));
    
    % Compute Lagrange basis elements evaluated at eigenvalue 
    ci = cheb_basis(d, e);

    % Compute ratio of condition number
    tempK = poly_abs_condition_number_ratio(ci,mi,coeff_cheb,coeff_mon_a);
    
    temp_arr = tempK(1:last_good_e);
    good_K = [good_K, mat2cell(temp_arr, length(temp_arr),1)];
    
    temp_arr = tempK(last_good_e+1:end);
    bad_K = [bad_K, mat2cell(temp_arr, length(temp_arr),1)]; %#ok<*AGROW>
    
    
    % Compute lower and upper bounds
    [u_cond_inf(d),l_cond_inf(d)] = bounds_simple(d,Vt);
    [u_cond_2(d), l_cond_2(d)] = bounds_cond_2(d,Vt);

end

good_X = cat(1, good_X{:})
bad_X = cat(1, bad_X{:});
good_K = cat(1,good_K{:});
bad_K = cat(1,bad_K{:});

x = 1:maxd;
scatter(good_X,good_K,[],'b');
%scatter(X,K)
hold on
scatter(bad_X,bad_K,[],'r');
set(gca,"yscale","log");
semilogy(x,u_cond_inf,'b-')
semilogy(x,l_cond_inf,'b-')
semilogy(x,u_cond_2, 'g-')
semilogy(x,l_cond_2, 'g-')

legend('good Condition Number','bad condition number',...
'cond inf','cond inf','cond 2','cond 2',...
    'Location', 'northwest')
xlabel('d')
ylabel('k')
title('Condition # Ratio (Chebyshev), Equispaced Nodes') 
%profile viewer
toc
hold off