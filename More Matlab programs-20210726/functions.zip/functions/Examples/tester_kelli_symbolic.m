% Tester!!!
% Let's try for interval [a,b] to start, and nxn matrix coefficients
tic
clear; clc; close all;
% endpoints of interval a and b
a = -1;
b = 1;

% size of matrices (nxn)
n = 3;

% number of iterations
maxd = 8;

% define accuracy
digits(40);

%profile on 

k = cell(maxd,1); 
u = zeros(maxd,1);
l = zeros(maxd,1);

for d = 1:maxd
    % Define monomial and Lagrange coefficient matrices & nodes
    coeff_mon = genP(d,n,a,b);
    % note that coeff_mon is cell
    
%     nodes = linspace(a,b,d+1); % equispaced
  
    nodes = zeros(1,d+1); % Chebyshev nodes first kind
    for j = 1:d+1
        nodes(j) = cos((2*j-1)*pi/(2*(d+1)));
    end
    
    Vt = fliplr(vander(nodes));
    % convert coeff_mon from cell to array here
    coeff_mon_a = reshape(cell2sym(coeff_mon),n,n,d+1);
    coeff_lag = getOtherMatrices(Vt, coeff_mon_a);

    % Find Eigenvalues 
    % Choose one eigenvalue by creating linearization, in order to use eig
    [L, ~] = Cp(coeff_mon);
    e = eig(L);

    % Compute sum of monomial basis elements evaluated at eigenvalue
    monomial_basis = poly2sym(ones(d+1,1));
    mi = subs(monomial_basis, abs(e));

    % Compute Lagrange basis elements evaluated at eigenvalue 
    li = LagrangeBasis(nodes, e);

    % Compute ratio of condition number
    k{d} = poly_abs_condition_number_ratio(li,mi,coeff_lag,coeff_mon_a);
    
    % Compute lower and upper bounds
    [u(d),l(d)] = bounds_simple(d,Vt);

end

t = [];
x = 1:maxd;
for i = 1:maxd
    t = [t; i*ones(n*i,1)];
end



semilogy(t,real(cell2sym(k)),'r.','LineWidth',2)
hold on
semilogy(x,u,'b-')
semilogy(x,l,'g-')
legend('Condition Number','Upper Bound','Lower Bound',...
    'Location', 'northwest')
xlabel('d')
ylabel('k')
title('Condition # Ratio (Lagrange/Monomial), Equispaced Nodes') 
%profile viewer
toc
