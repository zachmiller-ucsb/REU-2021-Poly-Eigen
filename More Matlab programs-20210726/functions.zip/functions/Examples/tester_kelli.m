% Tester!!!
% Let's try for interval [a,b] to start, and nxn matrix coefficients

clear; clc; close all;
% endpoints of interval a and b
a = -1;
b = 1;

% size of matrices (nxn)
n = 3;

% number of iterations
maxd = 14;

k = zeros(maxd,1); 
u = zeros(maxd,1);
l = zeros(maxd,1);

for d = 1:maxd
    % Define monomial and Lagrange coefficient matrices & nodes
    coeff_mon = a + abs(b-a)*rand(n,n,d+1);
    
    % nodes = linspace(a,b,d+1); % equispaced
    
    nodes = zeros(d+1,1); % Chebyshev nodes first kind
    for j = 1:d+1
        nodes(j) = cos((2*j-1)*pi/(2*(d+1)));
    end
    
    Vt = fliplr(vander(nodes));
    coeff_lag = getOtherMatrices(Vt, coeff_mon);

    % Find Eigenvalues 
    % Choose one eigenvalue
    matrices = mat2cell(coeff_mon,n, n, ones(d+1,1));
    e = polyeig(matrices{:});
    lambda0 = e(randi(length(e)));
    if lambda0 == 0
        warning('Eigenvalue = 0, d = %f', d) 
    end

    % Compute sum of monomial basis elements evaluated at eigenvalue
    monomial_basis = ones(d,1);
    mi = polyval(monomial_basis, abs(lambda0));

    % Compute Lagrange basis elements evaluated at eigenvalue 
    li = LagrangeBasis(nodes, lambda0);

    % Compute ratio of condition number
    k(d) = poly_abs_condition_number_ratio(li,mi,coeff_lag,coeff_mon);
    
    % Compute lower and upper bounds
    [u(d),l(d)] = bounds_simple(d,Vt);

end

semilogy(1:maxd,k,'r.','LineWidth',2)
hold on
semilogy(1:maxd,u,'b-')
semilogy(1:maxd,l,'g-')
legend('Condition Number','Upper Bound','Lower Bound',...
    'Location', 'northwest')
xlabel('d')
ylabel('k')
title('Condition # Ratio (Lagrange/Monomial), Chebyshev Nodes') 

