% Test program for getOtherMatrices
nodes = [1 2 3];
V = fliplr(vander(nodes));
P(:,:,1) = [1 1; 1 -1];
P(:,:,2) = [0 1; 1 0];
P(:,:,3) = [2 1; 1 2];
L = getOtherMatrices(V, P);
E(:,:,1) = P(:,:,1) + P(:,:,2) + P(:,:,3);
E(:,:,2) = P(:,:,1) + 2 * P(:,:,2) + 4 * P(:,:,3);
E(:,:,3) = P(:,:,1) + 3 * P(:,:,2) + 9 * P(:,:,3);
if ~isequal(L, E)
    error('The change of basis operation did not produce the expected result L = E');
end