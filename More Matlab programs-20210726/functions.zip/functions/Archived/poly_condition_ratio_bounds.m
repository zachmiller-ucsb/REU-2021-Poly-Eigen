function [k, u, l] = poly_condition_ratio_bounds(n,maxd,a,b,nodes,C,basis_x)
% This function generates the ratio of condition numbers for eigenvalues of 
% matrix polynomials (k) and the (simple) upper and lower bounds (u and l). 
% The inputs of this function include:
% -n (the size of the coefficient matrices is nxn),
% -maxd, which is the maximum degree of which matrix polynomial observed,
% -a & b, the endpoints of the interval,
% -nodes, a cell array size dx1, with nodes for each matrix polynomial of
% increasing degree,
% -C, the change of basis matrices from monomial to basis x (in cell
% format),
% -basis_x, a function that takes in the nodes in the first argument and 
% the values of which the elements of the basis are evaluated in the second
% argument and prodcues the basis elements as a 


k = cell(maxd,1); 
u = zeros(maxd,1);
l = zeros(maxd,1);
digits(40);

for d = 1:maxd
    % Define monomial coefficient matrices
    coeff_mon = genP(d,n,a,b);
    % note that coeff_mon is cell

    % convert coeff_mon from cell to array here
    coeff_mon_a = reshape(cell2sym(coeff_mon),n,n,d+1);
    % generate coefficients for basis x
    coeff_x = getOtherMatrices(C{d}, coeff_mon_a);

    % Finds eigenvalues by creating linearization, in order to use eig
    [L, ~] = Cp(coeff_mon);
    e = eig(L);

    % Compute sum of monomial basis elements evaluated at eigenvalue
    monomial_basis = poly2sym(ones(d+1,1));
    mi = subs(monomial_basis, abs(e));

    % Compute x basis elements evaluated at eigenvalue 
    xi = basis_x(nodes{d}, e);

    % Compute ratio of condition number
    k{d} = poly_abs_condition_number_ratio(xi,mi,coeff_x,coeff_mon_a);
    
    % Compute lower and upper bounds
    [u(d),l(d)] = bounds_simple(d,C{d});

end
end