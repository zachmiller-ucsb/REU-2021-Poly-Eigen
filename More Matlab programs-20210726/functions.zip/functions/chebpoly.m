function C = chebpoly(n)
% C = CHEBPOLY(N) returns Chebyshev polynomials of the first kind from 
% degree 0 to n

C = cell(n+1,1);   % using cell array because of the different matrix sizes
C{1} = 1;          % T_0 = 1
C{2} = [1 0];      % T_1 = x
for k = 3:n+1      % T_n = 2xT_n-1 - T_n-2
    C{k} = [2*C{k-1} 0] - [0 0 C{k-2}];
end
