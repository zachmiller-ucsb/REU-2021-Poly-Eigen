% evaluates absolute sum of cheb polynomials for each eigenvalue

function vals = cheb_basis(d,e)
    C = chebpoly(d);
    vals = zeros(size(e));
    for i = 1:d+1
        val = abs( subs( poly2sym(double(C{i}) ), e) );
        vals = vals(:) + val(:);
    end
end