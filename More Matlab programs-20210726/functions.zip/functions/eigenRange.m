function [good_e,bad_e, e, lastgoode] = eigenRange(e,r,c)
% The following function takes in the eigenvalues of a matrix polynomial
% and the radius and center of the circle in the complex plane minimally
% including all of the nodes. It produces the eigenvalues within this
% circle as the vector (good_e) and the eigenvalues outside of this circle
% as the vector (bad_e).

indices = find(abs(e-c) < r);
good_e = e(indices);
bad_e = e;
bad_e(indices) = [];
e = [good_e; bad_e];
lastgoode = length(good_e);

end