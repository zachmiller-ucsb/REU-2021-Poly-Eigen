% alternate function of cheb_basis used for testing purposes
% Note that this runs much slower

function vals = cheb_basis_2(d,e)
    vals = zeros(size(e));
    for i = 1:d+1
       vals = vals(:) + abs(cos((i-1)*acos(e)));
    end
end