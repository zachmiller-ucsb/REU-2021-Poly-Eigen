function [L1, L0]=colleaguelagrange(k,n)

%% Esta funcion genera el colleague pencil cuando el polinomio matricial esta expresado en la base de Lagrange. 

L1= zeros(nk, nk);
L0=zeros(nk,nk);

