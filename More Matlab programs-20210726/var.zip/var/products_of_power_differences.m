function [mink, maxk, products] = products_of_power_differences(b, n)

    products = sym(zeros(1, n+1));
    powers = sym(b).^(0:n);
    for k = 0:n
        powers_nobk = powers([1:k k+2:n+1]);
        products(k+1) = abs(prod(powers(k+1) - powers_nobk, 2));
    end
    [~, sortedidx] = sort(products, 'ascend');
    mink = sortedidx(1);
    maxk = sortedidx(n+1);
end