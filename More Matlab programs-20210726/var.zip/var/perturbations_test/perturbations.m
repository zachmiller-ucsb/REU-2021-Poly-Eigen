function [p, e, pc, ec, pm, em] = perturbations(d, n, a, b, error)
% Take the degree of the matrix polynomial d, the size of the matrix
% coefficients (nxn), and the interval a,b to choose matrix coefficients
% from, then return the coefficients of a new matrix polynomial in the
% monomial basis in the cell p, and also return the eigenvalues of this
% polynomial by calling eig() on the polynomial's colleague linearization.
% Do this twice: once for the actual polynomial, and again for the same
% polynomial perturbed by the given error.

    p = genP(d, n, a, b);
    [L, ~] = Cp(p);
    e = eig(L);
    p = cell2sym(p);
    p = reshape(p, n, n, d+1);
    pm = p + sym(error);
    x2m = std_xchg_chebyshev_monomial(d);
    pc = polygen_rewrite_polynomial(x2m ,p) + sym(error);
    [Lm, ~] = Cp(sym2cell(pm));
    [Lc, ~] = Cp(sym2cell(pc));
    ec = eig(Lc);
    em = eig(Lm);
end
