% Perturbation test script.
% This code does not seem to work at the moment.

d = 3;
[nodes, noderange] = nodes_chebyshev_d(d);
polysize = 3;

% Eigenvalue generators
%evgen = @evgen_normal1_left_tail;
%evgen = @evgen_normal1_right_tail;
evgen = @evgen_normal1_two_tail;

pkmean = 0;
pkwidth = 50;

error = sym(10e-16);
[evs, pks] = polygen_pseudosmith( ...
    d, polysize, nodes, noderange, evgen, pkmean, pkwidth);
pm = double(pks) + error;
x2m = std_xchg_chebyshev_monomial(d);
pc = double(polygen_rewrite_polynomial(x2m, pks) + error);
pm = mat2cell(pm, polysize, polysize, ones(1, d+1));
pc = mat2cell(pc, polysize, polysize, ones(1, d+1));

ec = polyeig(pc{:})
em = polyeig(pm{:})
