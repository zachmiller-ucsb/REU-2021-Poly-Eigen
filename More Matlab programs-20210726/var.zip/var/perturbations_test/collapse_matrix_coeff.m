function M = collapse_matrix_coeff(matrices)
    M = sym(zeros(size(matrices,1)));
    numMatrices = size(matrices, 3);
    for i = 1:numMatrices
        M = M + matrices(:,:,i)*sym('x')^(i-1);
    end
end