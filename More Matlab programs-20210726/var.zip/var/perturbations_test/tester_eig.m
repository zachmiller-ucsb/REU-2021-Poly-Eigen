% Perturbation test script.

d = 15;
[nodes, noderange] = nodes_chebyshev_d(d);
polysize = 2;

% Eigenvalue generators
% evgen = @evgen_normal1_left_tail;
% evgen = @evgen_normal1_right_tail;
evgen = @evgen_normal1_two_tail;

pkmean = 0;
pkwidth = 50;

error = sym(10e-16);

[evs, pks] = polygen_pseudosmith( ...
    d, polysize, nodes, noderange, evgen, pkmean, pkwidth);
[L, ~] = Cp(sym2cell(pks));
e = eig(L);

pkse = pks + error;
x2m = std_xchg_chebyshev_monomial(d);
bkse = polygen_rewrite_polynomial(x2m, pks) + sym(error);

[Lm, ~] = Cp(sym2cell(pkse));
[Lc, ~] = Cp(sym2cell(bkse));

ec = eig(Lc);
em = eig(Lm);

T = table(e, ec, em);
T(1:size(pks), :)
