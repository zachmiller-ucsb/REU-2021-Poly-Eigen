function [Cp,iAk] = Cp(P)
% Take cell array of matrix coefficients, return associated Cp

    Ak = P{length(P)};
    n = size(Ak);
    k = length(P) - 1;
    iAk = Ak \ eye(n);  % take inverse of Ak
    Cp = zeros(n*k);
    Cp = sym(Cp,'f');

    % place -inv(Ak) * A_{i} for i = k-1, k-2, ..., 0 on left partitions
    for i = 0:(k-1)
        Cp(1+i*n:i*n+n, 1:n) = -iAk*P{length(P)-(i+1)};
    end

    % put identity matrices in the top right partition
    i = 1;
    j = n+1;
    while j+1 <= (n*k)
        Cp(i:i+(n-1), j:j+(n-1)) = eye(n);
        i = i + n;
        j = j + n;
    end
end
