function [p, e] = findPwithEvals(d,n,a,b)
% Using the degree of the matrix polynomial (d), the size of the matrix
% coefficients (nxn), and the interval in which the matrix coefficients are
% chosen, the following generates a matrix polynomial in the monomial basis
% with coefficients in a cell called p and also finds the eigenvalues of
% this polynomial by first finding a colleague linearization and then
% utilizing eig.

p = genP(d,n,a,b);
[L, ~] = Cp(p);
e = eig(L);

end