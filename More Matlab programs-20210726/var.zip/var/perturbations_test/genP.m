function P = genP(d,n,a,b)
% Generate symbolic matrix polynomial with normally distributed random
% entries in the interval [a,b], with coefficient matrices of size nxn.
% The degree of the polynomial is d.

    P = cell(1,d+1);
    for i = 1:d+1
        P{i} = sym(a + abs(b-a)*randn(n), 'f');
    end
end
