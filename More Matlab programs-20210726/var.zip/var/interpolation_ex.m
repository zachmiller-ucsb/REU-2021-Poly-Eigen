clear; clc;
N = 5;
f = @(x) -sin(x + cos(x)./3);

figure
x = linspace(0,2*pi,N);
p = polyfit(x,f(x),N-1);
xx = linspace(x(1),x(end),1000);
plot(xx,polyval(p,xx),'b--','LineWidth',2)
hold on
plot(xx,f(xx),'k-','LineWidth',2)
plot(x,polyval(p,x),'r.','MarkerSize',32)
ylim([-1 1])
axis tight
grid on
% title('Lagrange Polynomial Interpolation')
position = get(gcf, 'Position');
position(3) = 1024;
position(4) = 768;
set(gcf, 'Position', position);
legend('Interpolation','Exact','Nodes','Location','northwest')

