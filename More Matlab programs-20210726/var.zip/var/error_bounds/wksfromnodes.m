function wks = wksfromnodes(d, nodes)
% Return the Lagrange basis denominator weights for the given nodes.

    denominators = stdnumerize(zeros(1, d+1));
    for k = 1:d+1
        xk = nodes(k);
        nodesnoxk = nodes([1:k-1, k+1:d+1]);
        denominators(k) = prod(xk - nodesnoxk);
    end
    wks = 1 ./ denominators;
end