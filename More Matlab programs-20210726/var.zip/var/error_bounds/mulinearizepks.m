function [Lx1, Lx0] = mulinearizepks(d, polysize, nodes, pks, mu)
% Return the Bueno linearization from section 4, split into the linear
% (Lx1) and constant (Lx0) parts.

    if mu < 0 || mu > d-1
        error('The parameter mu is out of range');
    end

    [K1x1, K1x0] = kmatrix(polysize, nodes, d+1, mu+1);
    [K2x1, K2x0] = kmatrix(polysize, nodes, mu+2, 1);
    [Mx1, Mx0] = mmatrix(d, polysize, nodes, pks, mu);

    K2x1t = K2x1.';
    K2x0t = K2x0.';

    lrows = size(Mx1, 1) + size(K1x1, 1);
    lcolumns = size(Mx1, 2) + size(K2x1t, 2);
    Lx1 = stdnumerize(zeros(lrows, lcolumns));
    Lx0 = stdnumerize(zeros(lrows, lcolumns));

    mwriteRowsX = 1:size(Mx1, 1);
    mwriteColumnsX = 1:size(Mx1, 2);
    Lx1(mwriteRowsX, mwriteColumnsX) = Mx1;
    Lx0(mwriteRowsX, mwriteColumnsX) = Mx0;

    k1writeRowsX = size(Mx1, 1) + 1:size(Mx1, 1) + size(K1x1, 1);
    k1writeColumnsX = 1:size(K1x1, 2);
    if ~isempty(k1writeRowsX) && ~isempty(k1writeColumnsX)
        Lx1(k1writeRowsX, k1writeColumnsX) = K1x1;
        Lx0(k1writeRowsX, k1writeColumnsX) = K1x0;
    end

    k2writeRowsX = 1:size(K2x1t, 1);
    k2writeColumnsX = size(Mx1, 2) + 1:size(Mx1, 2) + size(K2x1t, 2);
    if ~isempty(k2writeRowsX) && ~isempty(k2writeColumnsX)
        Lx1(k2writeRowsX, k2writeColumnsX) = K2x1t;
        Lx0(k2writeRowsX, k2writeColumnsX) = K2x0t;
    end
end


function [Kx1, Kx0] = kmatrix(polysize, nodes, topleftX, bottomrightX)
% Return a K matrix as per Bueno's paper (4.2) and (4.3), separated into
% the linear (Kx1) and constant terms (Kx0).  This code is written this way
% so that a single function can generate either K1 or K2.

    rowblocks = topleftX - bottomrightX - 1;
    if rowblocks < 1
        dimension = [0, 0];
    else
        dimension = [rowblocks, rowblocks + 1] * polysize;
    end
    Kx1 = stdnumerize(zeros(dimension));
    Kx0 = stdnumerize(zeros(dimension));
    id = stdnumerize(eye(polysize));
    for rowX = 0:rowblocks-1
        nodeX = topleftX - rowX;
        rowWriteX = rowX * polysize + 1:(rowX + 1) * polysize;
        Kx1(rowWriteX, rowWriteX) = id;
        Kx0(rowWriteX, rowWriteX) = id * -nodes(nodeX);
        Kx1(rowWriteX, rowWriteX + polysize) = -id;
        Kx0(rowWriteX, rowWriteX + polysize) = id * nodes(nodeX - 2);
    end
end


function [Mx1, Mx0] = mmatrix(d, polysize, nodes, pks, mu)
% Return an M matrix as per Bueno's paper (4.6), separated into the linear
% (Mx1) and constant terms (Mx0).

    n = polysize;  % rename for convenience

    rowblocks = mu + 1;
    columnblocks = d - mu;
    dimension = [rowblocks, columnblocks] * n;

    wks = wksfromnodes(d, nodes);
    Mx1 = stdnumerize(zeros(dimension));
    Mx0 = stdnumerize(zeros(dimension));

    columnWriteX = (columnblocks - 1) * n + 1 : columnblocks * n;
    for rowX = rowblocks:-1:2
        pksX = rowblocks - rowX + 1;
        wksX = pksX;
        nodeX = pksX + 1;
        rowReadX = (pksX - 1) * n + 1 : pksX * n;
        block = pks(rowReadX, 1:n) * wks(wksX);
        rowWriteX = (rowX - 1) * n + 1 : rowX * n;
        Mx1(rowWriteX, columnWriteX) = block;
        Mx0(rowWriteX, columnWriteX) = block * -nodes(nodeX);
    end

    rowWriteX = 1:n;
    for columnX = 2:columnblocks
        pksX = d + 1 - columnX;
        wksX = pksX;
        nodeX = pksX + 1;
        rowReadX = (pksX - 1) * n + 1 : pksX * n;
        block = pks(rowReadX, 1:n) * wks(wksX);
        columnWriteX = (columnX - 1) * n + 1 : columnX * n;
        Mx1(rowWriteX, columnWriteX) = block;
        Mx0(rowWriteX, columnWriteX) = block * -nodes(nodeX);
    end

    blockdp1 = pks(d * n + 1:(d+1) * n, 1:n) * wks(d+1);
    blockd = pks((d-1) * n + 1:d * n, 1:n) * wks(d);

    writeX = 1:n;
    Mx1(writeX, writeX) = blockdp1 + blockd;
    Mx0(writeX, writeX) = blockdp1 * -nodes(d) + blockd * -nodes(d+1);
end
