function verifyevs(d, nodes, polysize, pks, revs, reigs, levs, leigs)
% Verify the given eigenvalues and eigenvectors behave as expected.

    verifyevs_noduplicates(nodes, revs, levs);
    wks = wksfromnodes(d, nodes);

    rmax = 0;
    for k = 1:length(revs)
        rev = revs(k);
        plambda = evalplambda(d, nodes, polysize, pks, wks, rev);
        for j = 1:polysize:size(reigs, 1)
            reig = reigs(j:j+polysize-1, k);
            rmax = max(max(plambda * reig, [], 'All'), rmax);
        end
    end

    lmax = 0;
    for k = 1:length(levs)
        lev = levs(k);
        plambda = evalplambda(d, nodes, polysize, pks, wks, lev);
        for j = 1:polysize:size(leigs, 2)
            leig = leigs(k, j:j+polysize-1);
            lmax = max(max(leig * plambda, [], 'All'), lmax);
        end
    end

    fprintf(1, "d: %i, rmax: %e, lmax: %e\n", d, rmax, lmax);
end


function verifyevs_noduplicates(nodes, revs, levs)
    for k = 1:length(revs)
        if find(nodes == revs(k)) > 0
            error("A right eigenvalue is also an interpolation node");
        end
    end
    for k = 1:length(levs)
        if find(nodes == levs(k)) > 0
            error("A left eigenvalue is also an interpolation node");
        end
    end
end


function plambda = evalplambda(d, nodes, polysize, pks, wks, ev)
    plambda = stdnumerize(zeros(polysize));
    for j = 1:d+1
        rowReadX = (j-1) * polysize + 1:j * polysize;
        pk = pks(rowReadX, :);
        plambda = plambda + pk * (wks(j) / (ev - nodes(j)));
    end
    plambda = plambda * prod(ev - nodes);
end
