function ks = ksfromevs(d, nodes, polysize, pks, revs, reigs, ~, leigs)
% Return the condition numbers for the given eigenvalues and eigenvectors.

    reigsmax = size(reigs, 1);
    leigsmax = size(leigs, 2);
    evsmax = length(revs);

    wks = wksfromnodes(d, nodes);
    lksums = buildlksums(d, nodes, evsmax, revs, wks);

    ksmax = evsmax * reigsmax * leigsmax / polysize / polysize;
    ks = stdnumerize(zeros(1, ksmax));
    kwriteX = 1;
    pkstwonorm = stdtwonorm(pks);
    for evx = 1:evsmax
        ev = revs(evx);
        lksum = lksums(evx);
        pprimelambda = evalpprimelambda(d, nodes, polysize, pks, ev);
        for reigx = 1:polysize:reigsmax
            reig = reigs(reigx:reigx + polysize - 1, evx);
            reigtwonorm = stdtwonorm(reig);
            for leigx = 1:polysize:leigsmax
                leig = leigs(evx, leigx:leigx + polysize - 1);
                leigtwonorm = stdtwonorm(leig);
                ks(kwriteX) = pkstwonorm * lksum ...
                    * reigtwonorm * leigtwonorm ...
                    / abs(ev) / abs(conj(leig) * pprimelambda * reig);
                kwriteX = kwriteX + 1;
            end
        end
    end
end


function answer = buildlksums(d, nodes, evsmax, revs, wks)
    answer = stdnumerize(zeros(1, evsmax));
    for evx = 1:evsmax
        rev = revs(evx);
        lkabs = abs(prod(rev - nodes));
        lksum = answer(evx);
        for polyx = 1:d+1
            lksum = lksum + abs(wks(polyx) / (rev - nodes(polyx)));
        end
        answer(evx) = lksum * lkabs;
    end
end


function pprimelambda = evalpprimelambda(d, nodes, polysize, pks, ev)
    plagrange = reshape(pks.', polysize, polysize, d+1);
    Xm = inv(std_xchg_lagrange_monomial([], nodes, []));
    pmonomial = polygen_rewrite_polynomial(Xm, plagrange);

    pprimelambda = stdnumerize(zeros(polysize));
    evpower = 1;
    for k = 2:d+1
        pprimelambda = pprimelambda + pmonomial(:,:,k) * ((k-1) * evpower);
        evpower = evpower * ev;
    end
end
