function [ks, bounds] = error_bounds_ktest_d(d, polysize, ...
    tksgen, nodegen, ~)
% Generic error bounds experiment, answer the bounds obtained.

    preamble_numeric;

    rndstate = stdstartdeterministicrandom(d, polysize, 0, 0);

    [nodes, noderange] = nodegeneval(nodegen, d);
    nodes = stdnumerize(nodes);
    % Note that the tks are the pks in the Lagrange basis
    pks = stdnumerize(tksgen(d, polysize, noderange));

    mu = 0;
    [Lx1s, Lx0s] = mulinearizepks(d, polysize, nodes, pks, mu);
    reigmatrix = -(Lx1s\Lx0s);  % meaning -inv(Lx1s) * Lx0s
    [V, Dr] = eig(reigmatrix);
    leigmatrix = -(Lx1s.'\Lx0s.').';  % meaning -Lx0s * inv(Lx1s)
    [Wt, Dl] = eig(leigmatrix.');
    W = Wt.';

    % The following matrices should be essentially zero.
    % reigmatrix * V - V * Dr, for right eigenpairs
    % W * leigmatrix - Dl * W, for left eigenpairs
    % diag(Dr) - diag(Dl), for the eigenvalues

    revs = diag(Dr);
    reigs = V(1:(d-mu) * polysize, :);
    levs = diag(Dl);
    leigs = W(:, 1:(1+mu) * polysize);

    verifyevs(d, nodes, polysize, pks, revs, reigs, levs, leigs);

    ks = ksfromevs(d, nodes, polysize, pks, revs, reigs, levs, leigs);
    bounds = [];

    stdstopdeterministicrandom(rndstate);
end
