function condV = bounds_cond_V(~, nodes, ~, ~, ~)
% Return the infinite condition number of the Vandermonde matrix for the
% given nodes.

    V = stdvander(sym(nodes));
    condV = stdinfcond(V);
end