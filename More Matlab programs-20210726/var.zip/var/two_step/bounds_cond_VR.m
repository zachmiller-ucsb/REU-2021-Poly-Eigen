function condVR = bounds_cond_VR(d, nodes, ~, ~, ~)
% This code does not seem to work at the moment.

    condVR = bounds_cond_V(0, nodes, 0, 0, 0) ...
        / bounds_cond_R(d, nodes, 0, 0, 0);
end