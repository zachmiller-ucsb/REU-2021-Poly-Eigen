function condL = bounds_cond_L(d, ~, ~, ~, ~)
% Return the infinite condition number of the Chebyshev to monomial change
% of basis matrix.

    L = std_xchg_chebyshev_monomial(d);
    condL = stdinfcond(L);
end
