function condR = bounds_cond_R(d, nodes, ~, ~, ~)
% This code does not seem to work at the moment.

    preamble;

    R = zeros(d+1, d+1);
    syms x;
    % T = cell(d+1,1);
    % T{1} = 1;
    % T{2} = x;
    % for i = 2:d
    %     T{i+1} = 2*x*T{i} - T{i-1};
    % end
    % T = cell2mat(T);
    M = poly2sym(ones(1, d+1));

    C = std_chebyshev_polynomials(d);
    R = C .* M;
    for i = 1:d+1
        for j = 1:d+1
            R(i, j) = subs(T(i), x, nodes(j));
        end
    end
    condR = stdinfcond(R);
end