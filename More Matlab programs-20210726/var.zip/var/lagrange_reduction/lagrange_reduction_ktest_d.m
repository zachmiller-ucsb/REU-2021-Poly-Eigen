function answer = lagrange_reduction_ktest_d(d, polysize, ...
    tksgen, nodegen, vbagen, boundgens)
% Generic Lagrange reduction experiment, answer the bounds obtained.

    preamble_numeric;

    [nodes, noderange] = nodegeneval(nodegen, d);
    nodes = stdnumerize(nodes);
    tks = tksgen(d, polysize, noderange);
    vba = vbagen(nodes, noderange, tks);

    answer = lagrange_boundseval(boundgens, vba, tks);
end
