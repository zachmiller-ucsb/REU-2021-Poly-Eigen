%%%%%%%%%%%%%%%%%%%% Lagrange reduction test script.

% Modeled after generic_ev_test.

preamble;
figuresavepath = '.';
plotfontsize = 12;
plottitle = true;

polysize = 2;
degreerange = 1:12;

experiment = @lagrange_reduction_ktest_d;
% experiment = @lagrange_reduction_ktest_d_log10;

boundgens = {
   @bounds_lagrange_reduction_cond
   @bounds_lagrange_reduction_exact
};

% tksgen = @tksgen_normal;
tksgen = @tksgen_uniform;

% nodegen = {@nodes_chebyshev_d_f, [1]};
nodegen = {@nodes_unity_roots_d_cr, [1e1, 1.5]};
% nodegen = {@nodes_unity_roots_d_c_1odp1, [0]};
% nodegen = {@nodes_unity_roots_d_c_lejaupper, [1e1]);
% nodegen = {@nodes_unity_roots_d_c_sinpiodp1, [0]);
% nodegen = {@nodes_disk_d_cr, [0 1]};
% nodegen = {@nodes_udisk_d_cr, [0 1]};
% nodegen = {@nodes_equidistant_d_abf, [-1 1 1]};
% nodegen = {@nodes_equidistant_d_1dp1_f, [1]};
% nodegen = {@nodes_equidistant_d_pmd_f, [1]};
% nodegen = {@nodes_expplus_d_bf, [2 1]};
% nodegen = {@nodes_expminus_d_bf, [2 1]};
% nodegen = {@nodes_expplus_twosided_d_bf, [2 1]};
% nodegen = {@nodes_expminus_twosided_d_bf, [2 1]};
% nodegen = {@nodes_expplusminus_twosided_d_bf, [2 1]};

% vbagen = @vbagen_chebyshev;
% vbagen = @vbagen_lagrange;
% vbagen = @vbagen_monomial;
% vbagen = @vbagen_newton;
vbagen = @vbagen_taylor;


%%%%%%%%%%%%%%%%%%%% Set up result cell arrays.

% Meaning of each dimension of bound_data:
%   first level is per bound generator
%   second level is per upper / lower bound
%   third level is per degree
bound_data = zeros(length(boundgens), 2, max(degreerange));

% Meaning: scatter data for the eigenvalue condition number ratios.
ratio_data = cell(max(degreerange), 1);

%%%%%%%%%%%%%%%%%%%% Parallel for loop for actual computation.

% Due to parfor index restrictions, will have to swizzle results later.
par_bound_data = cell(max(degreerange), 1);

% Reverse the degree indexing so that parallel processing schedules better.
% Unfortunately, parfor requires a strictly increasing integer range.
dmax = length(degreerange);

tic
parfor dk = 1:dmax
    d = degreerange(dmax - dk + 1);
    par_bound_data{dk} = experiment(d, polysize, ...
        tksgen, nodegen, vbagen, boundgens);
end
toc

for dk = 1:dmax
    dwrite = degreerange(dmax - dk + 1);
    ratio_data(dwrite) = [];
    for j = 1:length(boundgens)
        bound_data(j, 1, dwrite) = par_bound_data{dk}(j, 1);
        bound_data(j, 2, dwrite) = par_bound_data{dk}(j, 2);
    end
end

plotgen = @generic_plot;
% plotgen = @generic_autosave_plot;

plotgen(@plotscatter_black, plotfontsize, plottitle, ...
    experiment, degreerange, tksgen, nodegen, vbagen, ...
    boundgens, bound_data, ratio_data, figuresavepath);
