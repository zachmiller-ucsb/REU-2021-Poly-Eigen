function answer = vbagen_newton(nodes, ~, ~)
% Return the collocation matrix for the Newton basis, given the nodes
% and the tks values.

    syms x;
    nnodes = stdnumerize(nodes);
    answer = stdnumerize(zeros(length(nodes)));
    newtonpoly = sym(stdnumerize(1));
    for k = 1:length(nodes)
        answer(k, :) = subs(newtonpoly, nnodes);
        newtonpoly = newtonpoly * (x - nnodes(k));
    end
end
