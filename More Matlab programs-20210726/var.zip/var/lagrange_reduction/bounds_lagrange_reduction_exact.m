function [u, l] = bounds_lagrange_reduction_exact(vba, tks)
% Return the exact condition number ratio bound based on the collocation
% matrix vba and the interpolation target values taken from the function T,
% passed in the column block matrix Tks.

    tksTwoNorm = stdtwonorm(tks);
    vbaTwoNorm = stdtwonorm(vba);  % same as stdtwonorm(va)
    invvba = inv(vba);
    invva = kron(invvba, eye(size(tks, 2)));

    numerator = vbaTwoNorm * stdtwonorm(invva * tks);
    u = 1 + numerator / tksTwoNorm;
    l = -Inf;
end
