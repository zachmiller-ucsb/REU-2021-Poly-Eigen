function answer = vbagen_monomial(nodes, ~, ~)
% Return the collocation matrix for the monomial basis, given the nodes
% and the tks values.

    answer = stdvander(stdnumerize(nodes));
end
