function [u, l] = bounds_lagrange_reduction_cond(vba, ~)
% Return the condition number ratio bound based on the 2-condition number
% of the collocation matrix vba.

    u = 1 + stdcond(vba);
    l = -Inf;
end
