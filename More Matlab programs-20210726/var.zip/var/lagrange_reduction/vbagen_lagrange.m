function answer = vbagen_lagrange(nodes, ~, ~)
% Return the collocation matrix for the Lagrange basis, given the nodes
% and the tks values.

    answer = eye(length(nodes));
end
