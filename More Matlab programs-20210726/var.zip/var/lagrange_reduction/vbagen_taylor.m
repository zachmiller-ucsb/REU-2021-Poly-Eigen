function answer = vbagen_taylor(nodes, noderange, ~)
% Return the collocation matrix for the Taylor basis, given the nodes
% and the tks values.

    syms x;
    n = length(nodes);
    [~, ~, center, ~] = stdexplainrange(noderange);
    answer = stdnumerize(zeros(n));
    taylorpoly = sym(1);
    taylorfactor = x - sym(center);
    for k = 1:n
        answer(k, :) = subs(taylorpoly, nodes);
        taylorpoly = taylorpoly * taylorfactor;
    end
end
