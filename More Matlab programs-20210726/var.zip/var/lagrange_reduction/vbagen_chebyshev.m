function answer = vbagen_chebyshev(nodes, ~, ~)
% Return the collocation matrix for the Chebyshev basis, given the nodes
% and the tks values.

    cps = std_chebyshev_polynomials(length(nodes));
    nnodes = stdnumerize(nodes);
    answer = stdnumerize(zeros(length(nodes)));
    for k = 1:length(nodes)
        cpsym = poly2sym(cps{k});
        answer(k, :) = subs(cpsym, nnodes);
    end
end
