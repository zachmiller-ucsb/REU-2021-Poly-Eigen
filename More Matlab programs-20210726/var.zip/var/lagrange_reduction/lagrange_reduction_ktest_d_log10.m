function answer = lagrange_reduction_ktest_d_log10(d, polysize, ...
    tksgen, nodegen, vbagen, boundgens)
% Generic Lagrange reduction experiment, answer the base 10 logarithm of
% the bounds obtained.

    answer = lagrange_reduction_ktest_d(d, polysize, ...
        tksgen, nodegen, vbagen, boundgens);
    answer = log10(answer);
end
