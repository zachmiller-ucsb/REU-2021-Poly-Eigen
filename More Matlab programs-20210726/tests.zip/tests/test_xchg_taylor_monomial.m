function answer = test_xchg_taylor_monomial()

    syms x;

    taylors = (x - sym(3)).^[0:4].';
    Xm = std_xchg_taylor_monomial(4, [], [1 2 3 4 5]);
    monomials = simplify(Xm * taylors);
    expected = [sym(1), x, x^2, x^3, x^4].';
    answer = isequal(monomials, expected);
end
