function answer = test_polygen_rewrite_polynomial_a()
    nodes = stdnumerize([-1 0 1 2]);
    d = length(nodes) - 1;
    polysize = 2;

    pmonomial = stdnumerize(zeros(polysize, polysize, d+1));
    for k = 1:polysize:(d+1)*polysize
        pmonomial(:, k:k+polysize-1) = k * eye(polysize);
    end
    Xm = std_xchg_lagrange_monomial(d+1, nodes);
    plagrange = polygen_rewrite_polynomial(Xm, pmonomial);

    divergence = stdnumerize(zeros(polysize));
    for k = 1:d+1
        monomialeval = stdnumerize(zeros(polysize));
        lagrangeeval = stdnumerize(zeros(polysize));
        for j = 1:(d+1)
            monomialeval = monomialeval + ...
                pmonomial(:, :, j) * nodes(k)^(j-1);
            lagrangeeval = lagrangeeval + ...
                plagrange(:, :, j) * ...
                prod(nodes(k) - nodes([1:j-1 j+1:d+1])) / ...
                prod(nodes(k) - nodes([1:k-1 k+1:d+1]));
        end
        divergence = ...
            max(divergence, abs(monomialeval - lagrangeeval));
    end
    answer = max(divergence, [], 'all') < eps(1);
end
