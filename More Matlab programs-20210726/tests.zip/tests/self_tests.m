function self_tests()

    preamble_numeric;

    rndstate = stdstartdeterministicrandom(0, 1, 2, 3);
    answer = run_test(@test_polygen_rewrite_polynomial_a) ...
        && run_test(@test_polygen_rewrite_polynomial_b) ...
        && run_test(@test_xchg_chebyshev_monomial) ...
        && run_test(@test_xchg_lagrange_monomial) ...
        && run_test(@test_xchg_newton_monomial) ...
        && run_test(@test_xchg_taylor_monomial);
    stdstopdeterministicrandom(rndstate);

    if answer
        fprintf(1, "Things appear to work.\n");
    end
end


function answer = run_test(testfh)

    answer = testfh();
    if ~answer
        fprintf("%s: failed\n", functions(testfh).function);
    end
end
