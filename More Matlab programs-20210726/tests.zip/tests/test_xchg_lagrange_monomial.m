function answer = test_xchg_lagrange_monomial()

    answer = true;
    nodes = sym([-1 0 1]);
    monomials = [poly2sym([1]) poly2sym([1 0]) poly2sym([1 0 0])].';
    lagranges = inv(stdvander(nodes).') * monomials;

    for k = 1:3
        evals = subs(lagranges(k), nodes);
        evals = simplify(evals);
        expected = stdnumerize(zeros(1, 3));
        expected(1, k) = sym(1);
        answer = answer && isequal(evals, expected);
    end
end
