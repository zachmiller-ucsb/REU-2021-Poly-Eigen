function answer = test_xchg_chebyshev_monomial()

    syms x;
    answer = true;

    chebyshevs = [sym(1), x, 2 * x^2 - 1].';
    monomials = std_xchg_chebyshev_monomial(2) * chebyshevs;
    expected = [sym(1), x, x^2].';
    answer = answer && isequal(monomials, expected);

    chebyshevs = [sym(1), x, 2 * x^2 - 1, 4 * x^3 - 3*x].';
    monomials = std_xchg_chebyshev_monomial(3) * chebyshevs;
    expected = [sym(1), x, x^2, x^3].';
    answer = answer && isequal(monomials, expected);
end
