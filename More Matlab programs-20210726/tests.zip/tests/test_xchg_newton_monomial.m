function answer = test_xchg_newton_monomial()

    syms x;

    nodes = sym([1 2 3]);
    nk1 = 1;
    nk2 = nk1 * (x - nodes(1));
    nk3 = nk2 * (x - nodes(2));
    newtons = [nk1 nk2 nk3].';
    monomials = std_xchg_newton_monomial(2, nodes) * newtons;
    monomials = simplify(monomials);
    expected = [sym(1), x, x^2].';
    answer = isequal(monomials, expected);
end
