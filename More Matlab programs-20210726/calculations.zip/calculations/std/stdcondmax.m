function answer = stdcondmax()
% Return a cutoff for conditioning of unimodular matrices.

    answer = 1e3;
end
