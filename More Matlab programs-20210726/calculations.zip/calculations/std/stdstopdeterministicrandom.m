function stdstopdeterministicrandom(rndstate)
% Reset the random number generator to its previous state.

    rng(rndstate);
end
