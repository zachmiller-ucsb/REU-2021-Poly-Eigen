function answer = stdnormalmax()
% Return a cutoff for normal distributions in terms of standard deviations.

    answer = 3;
end
