function preamble_numeric()
% Set up stable computation environment.

    format longg;
    digits(60);
end
